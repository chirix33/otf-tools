# Tier B baselines: findings

**Run:** E1-core (5 documents, 694 questions), complete: 40/40 jobs, 5,552 predictions. Each system's settings were picked on pilot20 (308 questions) and frozen before E1.
**Models:** Qwen3.6-27B and gpt-oss-20b. Gemma-4-31B was dropped (see Caveats).
**Systems:** ReAct-R (retrieval tools), ReAct-C (retrieval + Python tools), GraphRAG (local search), ReCode (recursive code agent).

The full tables, confidence intervals and significance tests are in `TIER_B_RESULTS.md`. This file is the interpretation.

## Results at a glance

Question accuracy on E1-core, %. A multiple-choice question counts only if every option is right.

| System | Qwen3.6-27B | gpt-oss-20b | Gap |
|---|---|---|---|
| ReAct-C | **81.0** | **52.5** | 28.5 |
| ReAct-R | 79.2 | 47.4 | 31.8 |
| ReCode | 59.9 | 9.4 | 50.6 |
| GraphRAG | 46.5 | 16.1 | 30.4 |

All 16 system-vs-system and model-vs-model differences are significant (paired exact McNemar test, p < 0.01), except one: ReAct-C vs ReAct-R on Qwen (p = 0.14).

## Findings

### 1. Simple tool-using agents beat the more elaborate baselines

On both models, a ReAct agent that browses the document with section and search tools is the strongest baseline:
- On Qwen, ReAct-R and ReAct-C are 79–81%.
- ReCode trails them by about 20 points.
- GraphRAG trails them by about 33 points.

The ranking is the same on every one of the five documents. Per-document ranges are narrow (for example, Qwen ReAct-C: 77.9–85.2%), so this is not one easy document carrying the result.

### 2. The Python tool helps a little

- **Qwen:** ReAct-C is 1.7 points above ReAct-R, which is not significant.
- **gpt-oss:** ReAct-C is 5.0 points above ReAct-R, which is significant (p = 0.008).

On Qwen, ReAct-C ran on the local GPU (NVFP4) and ReAct-R on OpenRouter, so that comparison also mixes serving setups (see Caveats).

### 3. Counterfactual questions are the shared ceiling

- **Best counterfactual score:** 42.2%, for Qwen ReAct-C and ReAct-R. Every other question type is 82–100% for those two.
- **Options vs whole questions:** at the option level the same systems get 64–73% right. They get most options of a counterfactual question right but rarely all of them.
- **No system solves:** 84 of 694 questions (12%), and 79 of those are counterfactual, which is 43% of all counterfactual questions.
- **Upper bound:** if you count a question as solved when any Qwen system got it, accuracy would be 85.9%; for gpt-oss, 65.7%.

These questions ask what would happen if an object were removed, which means simulating collisions that never happened. Retrieving the right text doesn't answer that.

### 4. gpt-oss-20b finds facts but fails the reasoning questions

- **Descriptive questions:** among answers it formatted correctly, gpt-oss ReAct is 93–95% correct, about the same as Qwen (97–99%).
- **Explanatory and predictive questions:** 15–40% for gpt-oss, against 83–100% for Qwen.

So the gap isn't mainly about locating information. It's about reasoning over the events in the text: causes, and what happens next.

### 5. Much of gpt-oss's loss is answer formatting, not just wrong answers

Share of gpt-oss answers that were not a valid answer object:

| System | Invalid answers, gpt-oss | Invalid answers, Qwen |
|---|---|---|
| ReAct-C | 10% | 7% |
| ReAct-R | 18% | 0.6% |
| GraphRAG | 22% | 2% |
| ReCode | 47% | 10% |

- **Typical mistakes:**
  - ending its turn with an empty reply;
  - answering a multiple-choice question in the free-text format (GraphRAG: 40–43% of explanatory and counterfactual answers);
  - writing Python-style quotes instead of JSON.
- **Under the same rules:** Qwen's error rate is far lower on every system.

All of these are scored wrong, exactly as for Qwen and as in the Tier A baselines. They're a real property of the model under this answer contract, but the "gpt-oss reasons worse" reading from finding 4 should be stated alongside this one.

### 6. ReCode depends most on the model

- **Qwen:** ReCode reaches 59.9%.
- **gpt-oss:** ReCode reaches 9.4%. This is the largest model gap of any system (50.6 points).

The traces show why. ReCode expects the model to put any decision it can't make yet into a sub-function that gets expanded later. Qwen does this. gpt-oss usually writes code that reads the right sections and then fills in an answer before seeing what it read. When its code crashes, the agent stops without an answer: 40% of gpt-oss ReCode questions ended with no answer.

### 7. GraphRAG is expensive and weak on this kind of document

- **Cost:** the knowledge-graph index costs 22.7M tokens for Qwen and 15.4M for gpt-oss across the five documents. That makes GraphRAG Qwen's most expensive baseline per correct answer: about 101k tokens, against 21k for ReAct-R.
- **Accuracy:** it's last or second-to-last on both models.
- **"Unknown" answers:** gpt-oss GraphRAG answered "unknown" for 256 of 694 questions (37%).

The documents are per-video records: object lists, event lists and motion tables. Entity-relationship summaries lose the frame-level detail the questions need.

Prompt auto-tuning (setting 3) was the only change on the dev set that mattered a lot. It roughly doubled GraphRAG's dev accuracy on both models: 20.5 → 57.8% for Qwen and 13.6 → 28.2% for gpt-oss.

### 8. The drop from dev set to E1 is mostly because pilot20 is easier

Every frozen setting scored 7–21 points higher on pilot20 than on E1-core. Most of that comes from the mix of question types:
- **Descriptive share:** 71% of pilot20 questions are descriptive (the easy type), against 39% of E1-core.
- **Reweighting:** if each system's pilot20 per-type accuracy is weighted to E1-core's question-type mix, the predicted score is within 0–4 points of the real E1 score (for example, gpt-oss ReAct-C: 52.5% predicted, 52.5% actual).
- **What's left:** the remaining 0–4 points is the expected optimism from picking the best of up to three settings.

So report the E1-core numbers. When citing dev numbers, give them per question type.

### 9. Cost

| | Qwen3.6-27B (hosted runs) | gpt-oss-20b |
|---|---|---|
| Whole Tier B budget (dev + indexing + E1) | $156 | $4.50 |
| Best system, cost per 1,000 correct answers | $24 (ReAct-R) | $0.81 (ReAct-C) |

- **Price vs accuracy:** gpt-oss costs about 35 times less but scores 28–51 points lower.
- **Cheapest systems:** ReAct uses the fewest tokens per correct answer on both models.
- **Most expensive:** GraphRAG (setup cost) and ReCode (repeated attempts).

## What to say in the paper

- The strongest Tier B baseline is a tool-using ReAct agent: Qwen 79–81%, gpt-oss 47–53%. GraphRAG and ReCode are clearly weaker and much more expensive per correct answer.
- Counterfactual questions remain unsolved by retrieval-plus-reasoning baselines: at most 42%, and 43% of them are solved by no baseline at all. This is the gap a simulation-based method should target.
- The model matters more than the system for ReCode and for the reasoning question types. Report both models.

## Caveats

- **Mixed serving for Qwen:** ReAct-C ran on the local GPU (NVFP4, vLLM); ReAct-R, GraphRAG and ReCode ran on OpenRouter (Alibaba). Compare Qwen's ReAct-C with the other Qwen systems with that in mind, and don't compare latency across the two setups.
- **Gemma dropped:** Gemma-4-31B was dropped on Oct 26. Its 16-bit OpenRouter providers were rate-limited and it would not have finished by the deadline. gpt-oss-20b (the Tier A model) was run instead.
- **Two fixes before gpt-oss started:**
  - Replies that OpenRouter marks as a provider failure are now retried instead of scored. Qwen had none of these.
  - A ReAct "finish" call without its required argument now gets an error back, so the model can try again. Qwen hit this once (one ReAct-C question, at most 0.14 points).
- **Costs:** these are estimated at list prices from the call logs. I checked a sample of real charges and they matched the list prices exactly.

## Addendum (Oct 28): Gemma-4-31B-think on E1-core

Gemma ran on OpenRouter (Crusoe, bf16) with the agreed deviation: no pilot20 selection. Each system reused the slot frozen for Qwen, recorded in `freeze/<system>__or-gemma-4-31b-think.json` with Qwen's config hash and Gemma's own. The run stopped at the 3 PM CDT cutoff.

| System | Status | Gemma accuracy | Qwen on the same questions | gpt-oss on the same questions |
|---|---|---|---|---|
| ReAct-C | **complete** (694/694) | **79.8%** | 81.0% | 52.5% |
| ReAct-R | **complete** (694/694) | **79.8%** | 79.2% | 47.4% |
| GraphRAG | **partial**: e1_d03, d06, d09 answered (428/694); d12 indexed but not answered; d15 not started | 48.4% | 44.4% | 15.0% |
| ReCode | **partial**: e1_d03 and d06 complete, d09 33/147 (314/694 in total) | 50.3% | 59.9% | 6.7% |

The partial rows are accuracy on the answered questions only, with Qwen and gpt-oss scored on the same questions. Don't compare them with the full-set numbers.

- **ReAct:** Gemma matches Qwen. Gemma vs Qwen is not significantly different for ReAct-C (p = 0.40) or ReAct-R (p = 0.67), and Gemma's ReAct-C and ReAct-R are tied with each other (p = 1.0). Both models are far above gpt-oss.
- **Format errors:** Gemma almost never breaks the answer format (4 and 3 invalid answers out of 694), unlike gpt-oss. Its best counterfactual score, 44.9% with ReAct-C, is still the ceiling seen for every model.
- **GraphRAG extraction failure rate during E1-core indexing: 0 of 205 chunks (0.0%)** across e1_d03, d06, d09 and d12, so standard indexing held for Gemma with Qwen's tuned prompts.
- **Rate limits:** Crusoe refused thousands of requests with 429. Each refusal was waited out and retried, and is logged in `calls.jsonl` as `rate_limited`. None was scored.
