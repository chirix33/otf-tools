# Tier B baselines: results and analysis

Generated 2026-10-28T15:10 from `runs/` by `scripts/tier_b_handoff.py` (re-run it to refresh). **10/12 system-model runs complete** on E1-core.

## 1. What was run

- **Benchmark:** CLEVRER document QA, E1-core = e1_d03, e1_d06, e1_d09, e1_d12, e1_d15 (694 questions, 100 videos, 265 pages). Development and selection used pilot20 only (308 questions); E1 questions were answered once, after the freeze.
- **Systems:** `react_c` = ReAct-C (retrieval + Python tools); `react_r` = ReAct-R (retrieval tools); `graphrag` = GraphRAG (local search); `recode` = ReCode (recursive code agent).
- **Shared caps:** at most 12 model calls per question and 16,384 output tokens per call; frozen sampling settings from `configs/models.json`; the same answer contract and scorer as Tier A.
- **Selection:** each system had up to 3 predefined candidate slots, run on all of pilot20 and chosen by accuracy, then fewer total tokens, then the earlier slot. The choice was frozen (config hash) before any E1 question.

Where each run was served:

| Model alias | Served by | Systems |
|---|---|---|
| `qwen3.6-27b` | local GPU, vLLM: nvidia/Qwen3.6-27B-NVFP4 | react_c |
| `or-qwen3.6-27b` | OpenRouter, provider Alibaba | react_r, graphrag, recode |
| `or-gpt-oss-20b` | OpenRouter, provider CoreWeave | react_c, react_r, graphrag, recode |
| `or-gemma-4-31b-think` | OpenRouter, provider Crusoe | react_c, react_r, graphrag, recode |

**Not complete:** graphrag on `or-gemma-4-31b-think`, recode on `or-gemma-4-31b-think` (deadline reached). Those rows are missing below.

## 2. Headline results (E1-core)

Question accuracy counts each question once (a multiple-choice question is correct only when every option is). 95% CIs are bootstrap intervals from the report. Tokens are per question; GraphRAG's one-time indexing cost is in *setup* and in the amortized column. Cost is at OpenRouter list prices (local runs: $0 API cost, GPU time instead).

| System | Model | Question acc. % [95% CI] | Option acc. % | Parse errors | Tokens / q | Amortized tokens / q | Calls / q | API cost (E1) | Latency / q (s) |
|---|---|---|---|---|---|---|---|---|---|
| ReAct-C (retrieval + Python tools) | `qwen3.6-27b` | **81.0** [78.0, 83.7] | 82.8 | 48 | 20,772 | 20,772 | 5.1 | local | 286 |
| ReAct-R (retrieval tools) | `or-qwen3.6-27b` | **79.2** [76.1, 82.1] | 86.5 | 4 | 16,627 | 16,627 | 5.0 | $13.22 | 82 |
| GraphRAG (local search) | `or-qwen3.6-27b` | **46.5** [42.8, 50.1] | 63.5 | 13 | 14,549 | 47,209 | 1.0 | $49.04 | 42 |
| ReCode (recursive code agent) | `or-qwen3.6-27b` | **59.9** [56.3, 63.4] | 69.9 | 70 | 35,041 | 35,041 | 5.0 | $28.03 | 192 |
| ReAct-C (retrieval + Python tools) | `or-gpt-oss-20b` | **52.5** [49.0, 56.3] | 65.8 | 71 | 10,815 | 10,815 | 6.0 | $0.30 | 13 |
| ReAct-R (retrieval tools) | `or-gpt-oss-20b` | **47.4** [43.5, 51.1] | 59.1 | 124 | 11,087 | 11,087 | 6.8 | $0.30 | 17 |
| GraphRAG (local search) | `or-gpt-oss-20b` | **16.1** [13.4, 19.0] | 32.9 | 151 | 11,419 | 33,564 | 1.0 | $1.39 | 10 |
| ReCode (recursive code agent) | `or-gpt-oss-20b` | **9.4** [7.2, 11.4] | 27.1 | 323 | 11,548 | 11,548 | 2.0 | $0.52 | 36 |
| ReAct-C (retrieval + Python tools) | `or-gemma-4-31b-think` | **79.8** [76.8, 82.8] | 85.0 | 4 | 17,124 | 17,124 | 5.7 | $2.32 | 123 |
| ReAct-R (retrieval tools) | `or-gemma-4-31b-think` | **79.8** [76.8, 82.7] | 85.2 | 3 | 16,184 | 16,184 | 6.0 | $2.18 | 213 |

## 3. Accuracy by question type

Question accuracy %, with n per type. Descriptive questions are exact match; the other three are multiple choice (all options must be right).

| System | Model | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|---|
| ReAct-C (retrieval + Python tools) | `qwen3.6-27b` | 97.0 (n=271) | 91.8 (n=170) | 95.6 (n=68) | 42.2 (n=185) |
| ReAct-R (retrieval tools) | `or-qwen3.6-27b` | 97.4 (n=271) | 82.3 (n=170) | 100.0 (n=68) | 42.2 (n=185) |
| GraphRAG (local search) | `or-qwen3.6-27b` | 72.3 (n=271) | 41.8 (n=170) | 26.5 (n=68) | 20.5 (n=185) |
| ReCode (recursive code agent) | `or-qwen3.6-27b` | 74.9 (n=271) | 52.9 (n=170) | 94.1 (n=68) | 31.9 (n=185) |
| ReAct-C (retrieval + Python tools) | `or-gpt-oss-20b` | 85.6 (n=271) | 35.9 (n=170) | 23.5 (n=68) | 29.7 (n=185) |
| ReAct-R (retrieval tools) | `or-gpt-oss-20b` | 80.1 (n=271) | 31.2 (n=170) | 11.8 (n=68) | 27.6 (n=185) |
| GraphRAG (local search) | `or-gpt-oss-20b` | 24.4 (n=271) | 15.9 (n=170) | 5.9 (n=68) | 8.1 (n=185) |
| ReCode (recursive code agent) | `or-gpt-oss-20b` | 15.1 (n=271) | 8.2 (n=170) | 5.9 (n=68) | 3.2 (n=185) |
| ReAct-C (retrieval + Python tools) | `or-gemma-4-31b-think` | 98.9 (n=271) | 79.4 (n=170) | 100.0 (n=68) | 44.9 (n=185) |
| ReAct-R (retrieval tools) | `or-gemma-4-31b-think` | 98.9 (n=271) | 85.3 (n=170) | 98.5 (n=68) | 40.0 (n=185) |

Descriptive subtypes (accuracy %):

| System | Model | count | exist | query_color | query_material | query_shape |
|---|---|---|---|---|---|---|
| ReAct-C (retrieval + Python tools) | `qwen3.6-27b` | 97.1 | 96.1 | 97.8 | 100.0 | 95.2 |
| ReAct-R (retrieval tools) | `or-qwen3.6-27b` | 95.2 | 96.1 | 100.0 | 100.0 | 100.0 |
| GraphRAG (local search) | `or-qwen3.6-27b` | 63.5 | 78.4 | 71.1 | 86.2 | 78.6 |
| ReCode (recursive code agent) | `or-qwen3.6-27b` | 68.3 | 76.5 | 80.0 | 75.9 | 83.3 |
| ReAct-C (retrieval + Python tools) | `or-gpt-oss-20b` | 82.7 | 82.3 | 93.3 | 89.7 | 85.7 |
| ReAct-R (retrieval tools) | `or-gpt-oss-20b` | 79.8 | 78.4 | 68.9 | 89.7 | 88.1 |
| GraphRAG (local search) | `or-gpt-oss-20b` | 26.9 | 33.3 | 15.6 | 31.0 | 11.9 |
| ReCode (recursive code agent) | `or-gpt-oss-20b` | 13.5 | 27.4 | 8.9 | 13.8 | 11.9 |
| ReAct-C (retrieval + Python tools) | `or-gemma-4-31b-think` | 100.0 | 96.1 | 97.8 | 100.0 | 100.0 |
| ReAct-R (retrieval tools) | `or-gemma-4-31b-think` | 99.0 | 96.1 | 100.0 | 100.0 | 100.0 |

## 4. Accuracy by document

Question accuracy % per E1-core document; the spread shows how stable each system is across documents.

| System | Model | e1_d03 | e1_d06 | e1_d09 | e1_d12 | e1_d15 | Range |
|---|---|---|---|---|---|---|---|
| ReAct-C (retrieval + Python tools) | `qwen3.6-27b` | 83.3 | 77.9 | 79.6 | 79.0 | 85.2 | 77.9-85.2 |
| ReAct-R (retrieval tools) | `or-qwen3.6-27b` | 81.8 | 78.5 | 78.2 | 75.0 | 82.4 | 75.0-82.4 |
| GraphRAG (local search) | `or-qwen3.6-27b` | 47.7 | 44.3 | 41.5 | 49.2 | 50.7 | 41.5-50.7 |
| ReCode (recursive code agent) | `or-qwen3.6-27b` | 58.3 | 60.4 | 60.5 | 58.9 | 61.3 | 58.3-61.3 |
| ReAct-C (retrieval + Python tools) | `or-gpt-oss-20b` | 56.1 | 47.7 | 51.0 | 53.2 | 54.9 | 47.7-56.1 |
| ReAct-R (retrieval tools) | `or-gpt-oss-20b` | 51.5 | 45.0 | 44.2 | 50.8 | 46.5 | 44.2-51.5 |
| GraphRAG (local search) | `or-gpt-oss-20b` | 15.2 | 10.7 | 19.0 | 20.2 | 16.2 | 10.7-20.2 |
| ReCode (recursive code agent) | `or-gpt-oss-20b` | 6.8 | 5.4 | 12.2 | 8.1 | 14.1 | 5.4-14.1 |
| ReAct-C (retrieval + Python tools) | `or-gemma-4-31b-think` | 79.5 | 79.2 | 77.6 | 79.8 | 83.1 | 77.6-83.1 |
| ReAct-R (retrieval tools) | `or-gemma-4-31b-think` | 81.1 | 79.2 | 78.2 | 76.6 | 83.8 | 76.6-83.8 |

## 5. Paired comparisons

Every system answered the same questions, so differences are tested pairwise with an exact McNemar test on the questions where exactly one of the two is right. *A only / B only* = questions only that system got right.

| A | B | A - B (pts) | A only | B only | p (exact McNemar) | Significant at 0.05 |
|---|---|---|---|---|---|---|
| react_c `qwen3.6-27b` | react_r `or-qwen3.6-27b` | +1.7 | 34 | 22 | 0.141 | no |
| react_c `qwen3.6-27b` | graphrag `or-qwen3.6-27b` | +34.4 | 255 | 16 | <0.001 | yes |
| react_c `qwen3.6-27b` | recode `or-qwen3.6-27b` | +21.0 | 166 | 20 | <0.001 | yes |
| react_r `or-qwen3.6-27b` | graphrag `or-qwen3.6-27b` | +32.7 | 238 | 11 | <0.001 | yes |
| react_r `or-qwen3.6-27b` | recode `or-qwen3.6-27b` | +19.3 | 142 | 8 | <0.001 | yes |
| graphrag `or-qwen3.6-27b` | recode `or-qwen3.6-27b` | -13.4 | 74 | 167 | <0.001 | yes |
| react_c `or-gpt-oss-20b` | react_r `or-gpt-oss-20b` | +5.0 | 100 | 65 | 0.008 | yes |
| react_c `or-gpt-oss-20b` | graphrag `or-gpt-oss-20b` | +36.3 | 282 | 30 | <0.001 | yes |
| react_c `or-gpt-oss-20b` | recode `or-gpt-oss-20b` | +43.1 | 320 | 21 | <0.001 | yes |
| react_r `or-gpt-oss-20b` | graphrag `or-gpt-oss-20b` | +31.3 | 245 | 28 | <0.001 | yes |
| react_r `or-gpt-oss-20b` | recode `or-gpt-oss-20b` | +38.0 | 294 | 30 | <0.001 | yes |
| graphrag `or-gpt-oss-20b` | recode `or-gpt-oss-20b` | +6.8 | 97 | 50 | <0.001 | yes |
| react_c `or-gemma-4-31b-think` | react_r `or-gemma-4-31b-think` | +0.0 | 21 | 21 | 1.000 | no |
| react_c `qwen3.6-27b` | react_c `or-gpt-oss-20b` | +28.5 | 215 | 17 | <0.001 | yes |
| react_c `qwen3.6-27b` | react_c `or-gemma-4-31b-think` | +1.2 | 39 | 31 | 0.403 | no |
| react_c `or-gpt-oss-20b` | react_c `or-gemma-4-31b-think` | -27.4 | 13 | 203 | <0.001 | yes |
| react_r `or-qwen3.6-27b` | react_r `or-gpt-oss-20b` | +31.8 | 238 | 17 | <0.001 | yes |
| react_r `or-qwen3.6-27b` | react_r `or-gemma-4-31b-think` | -0.6 | 23 | 27 | 0.672 | no |
| react_r `or-gpt-oss-20b` | react_r `or-gemma-4-31b-think` | -32.4 | 17 | 242 | <0.001 | yes |
| graphrag `or-qwen3.6-27b` | graphrag `or-gpt-oss-20b` | +30.4 | 243 | 32 | <0.001 | yes |
| recode `or-qwen3.6-27b` | recode `or-gpt-oss-20b` | +50.6 | 370 | 19 | <0.001 | yes |

## 6. Development selection on pilot20

All candidates of each system on pilot20 (308 questions) and the frozen choice. *Dev to E1* compares the frozen slot's pilot20 accuracy with its E1-core accuracy.

| System | Model | Slot | pilot20 acc. % | Total tokens | Parse errors | Index | Dev to E1 |
|---|---|---|---|---|---|---|---|
| ReAct-C (retrieval + Python tools) | `qwen3.6-27b` | 1 (selected) | 89.9 | 4,789,463 | 12 | - | 89.9 -> 81.0 |
| ReAct-R (retrieval tools) | `or-qwen3.6-27b` | 1 (selected) | 89.9 | 4,080,810 | 0 | - | 89.9 -> 79.2 |
| ReAct-R (retrieval tools) | `or-qwen3.6-27b` | 2 | 89.6 | 4,069,408 | 0 | - |  |
| ReAct-R (retrieval tools) | `or-qwen3.6-27b` | 3 | 87.3 | 3,732,897 | 0 | - |  |
| GraphRAG (local search) | `or-qwen3.6-27b` | 1 | 20.5 | 3,263,296 | 31 | standard |  |
| GraphRAG (local search) | `or-qwen3.6-27b` | 2 | 21.8 | 3,283,622 | 15 | standard |  |
| GraphRAG (local search) | `or-qwen3.6-27b` | 3 (selected) | 57.8 | 8,221,572 | 4 | standard | 57.8 -> 46.5 |
| ReCode (recursive code agent) | `or-qwen3.6-27b` | 1 | 66.6 | 11,332,409 | 45 | - |  |
| ReCode (recursive code agent) | `or-qwen3.6-27b` | 2 | 69.8 | 10,191,346 | 30 | - |  |
| ReCode (recursive code agent) | `or-qwen3.6-27b` | 3 (selected) | 72.7 | 10,906,666 | 33 | - | 72.7 -> 59.9 |
| ReAct-C (retrieval + Python tools) | `or-gpt-oss-20b` | 1 | 71.1 | 3,122,263 | 35 | - |  |
| ReAct-C (retrieval + Python tools) | `or-gpt-oss-20b` | 2 | 69.5 | 3,294,009 | 33 | - |  |
| ReAct-C (retrieval + Python tools) | `or-gpt-oss-20b` | 3 (selected) | 71.4 | 2,985,218 | 26 | - | 71.4 -> 52.5 |
| ReAct-R (retrieval tools) | `or-gpt-oss-20b` | 1 | 65.6 | 3,349,464 | 47 | - |  |
| ReAct-R (retrieval tools) | `or-gpt-oss-20b` | 2 | 66.9 | 3,489,296 | 45 | - |  |
| ReAct-R (retrieval tools) | `or-gpt-oss-20b` | 3 (selected) | 68.5 | 3,291,008 | 44 | - | 68.5 -> 47.4 |
| GraphRAG (local search) | `or-gpt-oss-20b` | 1 | 13.6 | 2,333,691 | 49 | standard |  |
| GraphRAG (local search) | `or-gpt-oss-20b` | 2 | 12.3 | 2,352,793 | 36 | standard |  |
| GraphRAG (local search) | `or-gpt-oss-20b` | 3 (selected) | 28.2 | 6,174,034 | 30 | standard | 28.2 -> 16.1 |
| ReCode (recursive code agent) | `or-gpt-oss-20b` | 1 | 8.8 | 4,246,269 | 177 | - |  |
| ReCode (recursive code agent) | `or-gpt-oss-20b` | 2 | 12.3 | 4,325,717 | 175 | - |  |
| ReCode (recursive code agent) | `or-gpt-oss-20b` | 3 (selected) | 16.6 | 3,620,819 | 135 | - | 16.6 -> 9.4 |
| ReAct-C (retrieval + Python tools) | `or-gemma-4-31b-think` | 1 (reused) | not run | - | - | - | slot and settings of `qwen3.6-27b` (hash `2237726337f8b1ab`); own hash `00e443b1b2e9eb99` |
| ReAct-R (retrieval tools) | `or-gemma-4-31b-think` | 1 (reused) | not run | - | - | - | slot and settings of `or-qwen3.6-27b` (hash `40fe3497f1479208`); own hash `5cdb2503547f526d` |
| GraphRAG (local search) | `or-gemma-4-31b-think` | 3 (reused) | not run | - | - | standard | slot and settings of `or-qwen3.6-27b` (hash `993f8f4f498ff189`); own hash `319ed863e10a70f8` |
| ReCode (recursive code agent) | `or-gemma-4-31b-think` | 3 (reused) | not run | - | - | - | slot and settings of `or-qwen3.6-27b` (hash `a85015f55f974ee3`); own hash `5f5d068874d5dc93` |

GraphRAG indexing for `or-qwen3.6-27b`: **standard** (rule: fast if failed_fraction > 0.1; standard extraction failed on 0/50 pilot20 chunks).

GraphRAG indexing for `or-gpt-oss-20b`: **standard** (rule: fast if failed_fraction > 0.1; standard extraction failed on 0/50 pilot20 chunks).

GraphRAG entity extraction while indexing E1-core (a chunk fails when extraction raised, or it returned no entities and no completion marker):

| Model | Document | Chunks | Failed | Failure rate | Empty but completed |
|---|---|---|---|---|---|
| `or-qwen3.6-27b` | e1_d03 | 54 | 0 | 0.0% | 0 |
| `or-qwen3.6-27b` | e1_d06 | 49 | 0 | 0.0% | 0 |
| `or-qwen3.6-27b` | e1_d09 | 50 | 0 | 0.0% | 0 |
| `or-qwen3.6-27b` | e1_d12 | 52 | 0 | 0.0% | 0 |
| `or-qwen3.6-27b` | e1_d15 | 52 | 0 | 0.0% | 0 |
| `or-gpt-oss-20b` | e1_d03 | 54 | 0 | 0.0% | 0 |
| `or-gpt-oss-20b` | e1_d06 | 49 | 0 | 0.0% | 0 |
| `or-gpt-oss-20b` | e1_d09 | 50 | 0 | 0.0% | 0 |
| `or-gpt-oss-20b` | e1_d12 | 52 | 0 | 0.0% | 0 |
| `or-gpt-oss-20b` | e1_d15 | 52 | 0 | 0.0% | 0 |
| `or-gemma-4-31b-think` | e1_d03 | 54 | 0 | 0.0% | 0 |
| `or-gemma-4-31b-think` | e1_d06 | 49 | 0 | 0.0% | 0 |
| `or-gemma-4-31b-think` | e1_d09 | 50 | 0 | 0.0% | 0 |
| `or-gemma-4-31b-think` | e1_d12 | 52 | 0 | 0.0% | 0 |
| `or-qwen3.6-27b` | **all** | 257 | 0 | **0.0%** | 0 |
| `or-gpt-oss-20b` | **all** | 257 | 0 | **0.0%** | 0 |
| `or-gemma-4-31b-think` | **all** | 205 | 0 | **0.0%** | 0 |

## 7. Cost and efficiency

Tokens per correct answer = all E1 tokens (including setup) / correctly answered questions. Lower is better.

| System | Model | E1 tokens (all) | of which setup | Reasoning share of output | Tokens / correct answer | API cost | Cost / 1,000 correct |
|---|---|---|---|---|---|---|---|
| ReAct-C (retrieval + Python tools) | `qwen3.6-27b` | 14,415,815 | 0 | 93% | 25,651 | local | - |
| ReAct-R (retrieval tools) | `or-qwen3.6-27b` | 11,539,309 | 0 | 96% | 20,981 | $13.22 | $24.04 |
| GraphRAG (local search) | `or-qwen3.6-27b` | 32,762,999 | 22,665,962 | 99% | 101,433 | $49.04 | $151.83 |
| ReCode (recursive code agent) | `or-qwen3.6-27b` | 24,318,751 | 0 | 93% | 58,459 | $28.03 | $67.39 |
| ReAct-C (retrieval + Python tools) | `or-gpt-oss-20b` | 7,505,376 | 0 | 94% | 20,619 | $0.30 | $0.81 |
| ReAct-R (retrieval tools) | `or-gpt-oss-20b` | 7,694,372 | 0 | 92% | 23,387 | $0.30 | $0.92 |
| GraphRAG (local search) | `or-gpt-oss-20b` | 23,293,377 | 15,368,448 | 106% | 207,977 | $1.39 | $12.38 |
| ReCode (recursive code agent) | `or-gpt-oss-20b` | 8,014,605 | 0 | 98% | 123,302 | $0.52 | $7.97 |
| ReAct-C (retrieval + Python tools) | `or-gemma-4-31b-think` | 11,883,974 | 0 | 74% | 21,451 | $2.32 | $4.20 |
| ReAct-R (retrieval tools) | `or-gemma-4-31b-think` | 11,232,075 | 0 | 74% | 20,275 | $2.18 | $3.94 |

Whole Tier B budget from the call ledgers (every successful call: pilot20 development, GraphRAG indexing and prompt tuning, E1), at list prices:

| Model | Input tokens | Output tokens | API cost |
|---|---|---|---|
| `qwen3.6-27b` | 14,460,917 | 5,554,428 | local |
| `or-qwen3.6-27b` | 83,376,469 | 43,858,592 | $155.94 |
| `or-gpt-oss-20b` | 70,880,792 | 18,270,252 | $4.50 |
| `or-gemma-4-31b-think` | 39,347,553 | 13,041,097 | $10.73 |

## 8. Failure modes

From each prediction's trace. A parse error is a reply without a valid answer object (scored wrong). *Truncated* = the 16,384-token output cap was hit. *Call cap* = the 12-call budget ran out. *No answer* = the agent stopped without submitting one.

| System | Model | Parse errors | Truncated | Call cap | Retried infra errors | Outcomes | Parse error kinds |
|---|---|---|---|---|---|---|---|
| ReAct-C (retrieval + Python tools) | `qwen3.6-27b` | 48 | 35 | 0 | 0 | finish: 488, answered_without_finish: 206 | no JSON object: 43, missing 'choices': 5 |
| ReAct-R (retrieval tools) | `or-qwen3.6-27b` | 4 | 0 | 0 | 0 | finish: 459, answered_without_finish: 235 | missing 'choices': 3, no JSON object: 1 |
| GraphRAG (local search) | `or-qwen3.6-27b` | 13 | 0 | 0 | 0 | answered: 694 | missing 'choices': 13 |
| ReCode (recursive code agent) | `or-qwen3.6-27b` | 70 | 0 | 6 | 2 | answered: 631, no_answer: 57, call_cap_exhausted: 6 | no JSON object: 63, missing 'answer': 4, missing 'choices': 3 |
| ReAct-C (retrieval + Python tools) | `or-gpt-oss-20b` | 71 | 0 | 1 | 1 | finish: 358, answered_without_finish: 335, call_cap_exhausted: 1 | no JSON object: 62, missing 'choices': 7, missing 'answer': 2 |
| ReAct-R (retrieval tools) | `or-gpt-oss-20b` | 124 | 0 | 28 | 2 | answered_without_finish: 368, finish: 298, call_cap_exhausted: 28 | no JSON object: 123, missing 'answer': 1 |
| GraphRAG (local search) | `or-gpt-oss-20b` | 151 | 0 | 0 | 0 | answered: 694 | missing 'choices': 149, no JSON object: 2 |
| ReCode (recursive code agent) | `or-gpt-oss-20b` | 323 | 0 | 5 | 0 | answered: 409, no_answer: 280, call_cap_exhausted: 5 | no JSON object: 297, missing 'choices': 18, missing 'answer': 8 |
| ReAct-C (retrieval + Python tools) | `or-gemma-4-31b-think` | 4 | 2 | 2 | 1 | answered_without_finish: 571, finish: 121, call_cap_exhausted: 2 | no JSON object: 4 |
| ReAct-R (retrieval tools) | `or-gemma-4-31b-think` | 3 | 0 | 3 | 0 | answered_without_finish: 512, finish: 179, call_cap_exhausted: 3 | no JSON object: 3 |

## 9. Key findings

- **qwen3.6-27b:** react_c 81.0% > react_r 79.2% > recode 59.9% > graphrag 46.5% (spread 34.4 points).
- **gpt-oss-20b:** react_c 52.5% > react_r 47.4% > graphrag 16.1% > recode 9.4% (spread 43.1 points).
- **gemma-4-31b-think:** react_c 79.8% > react_r 79.8% (spread 0.0 points).
- Best overall: **react_c on `qwen3.6-27b`** at 81.0% question accuracy.
- Descriptive: best react_c `or-gemma-4-31b-think` 98.9%, worst recode `or-gpt-oss-20b` 15.1%.
- Explanatory: best react_c `qwen3.6-27b` 91.8%, worst recode `or-gpt-oss-20b` 8.2%.
- Predictive: best react_r `or-qwen3.6-27b` 100.0%, worst graphrag `or-gpt-oss-20b` 5.9%.
- Counterfactual: best react_c `or-gemma-4-31b-think` 44.9%, worst recode `or-gpt-oss-20b` 3.2%.
- The hardest question type is **counterfactual** for 7 of 10 runs (all options of a multiple-choice question must be right; option-level accuracy in the report is much higher).
- Most token-efficient: react_r `or-gemma-4-31b-think` at 20,275 tokens per correct answer; least: graphrag `or-gpt-oss-20b` at 207,977.
- Not significantly different (paired test, p >= 0.05): react_c `qwen3.6-27b` vs react_r `or-qwen3.6-27b` (p=0.14); react_c `or-gemma-4-31b-think` vs react_r `or-gemma-4-31b-think` (p=1.00); react_c `qwen3.6-27b` vs react_c `or-gemma-4-31b-think` (p=0.40); react_r `or-qwen3.6-27b` vs react_r `or-gemma-4-31b-think` (p=0.67).
- Dev-to-E1 gap: the frozen configurations scored +7.2 (recode `or-gpt-oss-20b`) to +21.1 (react_r `or-gpt-oss-20b`) points higher on pilot20 than on E1-core. Some of this is selection on the dev set (the best of up to 3 slots), the rest is a difference in difficulty between pilot20 and the E1-core documents; E1 numbers are the ones to report.

## 10. Caveats and deviations from the plan

- Mixed serving: react_c on `qwen3.6-27b` ran on the local GPU (NVFP4 checkpoint, vLLM); the other runs used OpenRouter with one pinned provider per model. Same model weights family and sampling settings, but different quantisation and serving stack, so compare systems within one serving where possible. Latency is not comparable across servings.
- Gemma (`or-gemma-4-31b-think`), added 2026-10-28, deviates from the protocol: there was no pilot20 development stage. Each system reused the slot and settings frozen for Qwen (ReAct-C from the local Qwen run, the others from the OpenRouter Qwen runs; GraphRAG with Qwen's auto-tuned prompts and standard indexing, without the pilot20 extraction check), and ran on E1-core only. Its freeze files record the reused slot and both config hashes. Crusoe, the only bf16 provider that accepts the prompt lengths, rate-limits Gemma: refused (429) requests were retried with backoff and are logged in `calls.jsonl` as failed attempts, never scored.
- Two robustness fixes were added on 2026-10-26, before gpt-oss-20b's development stage (its first attempt was discarded after a few minutes; kept in `_discarded_runs/`): (1) a reply that OpenRouter ends with finish_reason "error" (a provider failure mid-generation) is retried as an infrastructure error instead of being scored; Qwen's runs had no such replies. (2) In ReAct, calling `finish` without its `answer_json` argument returns an error to the model, which can call again within the 12-call cap; before, it ended the question with an empty answer. Qwen did this once (ReAct-C, e1_d03, question 13778-6, scored wrong), so Qwen's ReAct-C score could be at most one question (0.14 points) higher under the new rule. Empty replies (no text, no tool call) remain a model outcome for both models, as in the Tier A baselines.
- GraphRAG token accounting: 1848 rows (answers and ledger entries, mostly pilot20) recorded through LiteLLM's streaming path missed reasoning tokens; they were corrected from the reasoning counts the provider returned (`scripts/repair_stream_usage.py`, rows marked `usage_corrected`). Later calls are sent non-streamed, so their counts are exact. Answers were unaffected.
- Cached input tokens: `or-qwen3.6-27b` reported none (the provider does not return them), so those rows show 0 cached tokens; it does not mean no prompt reuse happened.
- Reasoning tokens above output tokens (graphrag `or-gpt-oss-20b`): on GraphRAG's LiteLLM path the reasoning count is LiteLLM's own estimate, while output tokens (which include reasoning) are the provider's billed count. Totals and costs use the output count, so they are unaffected.
- Errored attempts (network/provider errors) were retried and are excluded from scoring; every question has exactly one scored answer (see `reports/delivery_manifest.json`).
- API costs are estimates at list prices from the token ledgers; the OpenRouter invoice is the authoritative number.

## 11. Files in this folder

- `reports/e1_report.md` / `.json`: the benchmark's own aggregate report (per-question correctness in the JSON); `reports/e1_dXX_report.*`: per document.
- `reports/DELIVERY.md`, `reports/delivery_manifest.json`: completeness check, SHA-256 of every prediction file, where each run was served, failure counts.
- `e1/<document>/<system>__<model>/predictions.jsonl`: one line per question: raw output, parsed answer, score, token usage, latency and the full agent trace. `calls.jsonl`: every model call (including failed attempts) with its usage. `setup.json`: one-time setup cost and provenance.
- `dev/pilot20/<system>_c<slot>__<model>/`: every development candidate, same format.
- `freeze/`: frozen selections (`<system>__<model>.json`, with config hashes), the GraphRAG indexing decision, the auto-tuned GraphRAG prompts and the SPEC sec. 11 block.
- `provenance.json`: repository commit, dependency versions, checkpoints/providers, package checksums. `timing.json`: wall-clock time per stage.
- `SHA256SUMS.txt`: checksums of every file here.
