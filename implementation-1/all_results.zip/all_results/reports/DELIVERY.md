# Tier B delivery (partial)

Generated 2026-10-28T15:10:15; deadline 2026-10-28T15:00:00-05:00.
Jobs complete: 55/60; predictions 7682/8328.

**Partial delivery** (deadline reached). Unfinished jobs:

| Model | System | Document | Answered |
|---|---|---|---|
| or-gemma-4-31b-think | graphrag | e1_d12 | 0/124 |
| or-gemma-4-31b-think | graphrag | e1_d15 | 0/142 |
| or-gemma-4-31b-think | recode | e1_d09 | 33/147 |
| or-gemma-4-31b-think | recode | e1_d12 | 0/124 |
| or-gemma-4-31b-think | recode | e1_d15 | 0/142 |

Where each job ran (the same model can come from two servings; compare within one serving):

- `qwen3.6-27b` (local vLLM: nvidia/Qwen3.6-27B-NVFP4): react_c
- `or-qwen3.6-27b` (hosted: https://openrouter.ai/api/v1 qwen/qwen3.6-27b, provider Alibaba): react_r, graphrag, recode
- `or-gpt-oss-20b` (hosted: https://openrouter.ai/api/v1 openai/gpt-oss-20b, provider CoreWeave): react_c, react_r, graphrag, recode
- `or-gemma-4-31b-think` (hosted: https://openrouter.ai/api/v1 google/gemma-4-31b-it, provider Crusoe): react_c, react_r, graphrag, recode

| System | Answered | Parse errors | Truncated | Call cap | Unknown-usage calls | Errored attempts |
|---|---|---|---|---|---|---|
| react_c__qwen3.6-27b | 694 | 48 | 35 | 0 | 0 | 0 |
| react_r__or-qwen3.6-27b | 694 | 4 | 0 | 0 | 0 | 0 |
| graphrag__or-qwen3.6-27b | 694 | 13 | 0 | 0 | 0 | 0 |
| recode__or-qwen3.6-27b | 694 | 70 | 0 | 6 | 0 | 2 |
| react_c__or-gpt-oss-20b | 694 | 71 | 0 | 1 | 0 | 1 |
| react_r__or-gpt-oss-20b | 694 | 124 | 0 | 28 | 0 | 2 |
| graphrag__or-gpt-oss-20b | 694 | 151 | 0 | 0 | 0 | 0 |
| recode__or-gpt-oss-20b | 694 | 323 | 0 | 5 | 0 | 0 |
| react_c__or-gemma-4-31b-think | 694 | 4 | 2 | 2 | 0 | 1 |
| react_r__or-gemma-4-31b-think | 694 | 3 | 0 | 3 | 0 | 0 |
| graphrag__or-gemma-4-31b-think | 428 | 9 | 0 | 0 | 0 | 0 |
| recode__or-gemma-4-31b-think | 314 | 117 | 0 | 9 | 0 | 0 |

GraphRAG 3.3.0 (5faaaf4f5685fa2056fa8c3bf9342cb089f2942f); ReCode 6e7223f71281d914762e78d7bbcf6446d362ecbc. Accuracy/cost reports: runs/e1_report.md and runs/e1_dXX/report.md.
