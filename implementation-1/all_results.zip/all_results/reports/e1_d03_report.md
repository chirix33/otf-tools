# CLEVRER document-QA benchmark: e1_d03

- Videos: 20 (validation split, seed None), questions: 132
- Document: `C:\Users\htripathi\PycharmProjects\OTF\otf-tools\implementation-1\runs\e1_d03\document.pdf` (56 pages), rendered from ground-truth annotations (observed 128 frames only; motion log every 8 frames + event frames)
- Descriptive: exact match. Multiple-choice: per-option accuracy, and per-question accuracy (all options of the question correct). Overall question accuracy counts each question once.

## Overall

| System | Model | Answered | Errors | Question acc. (%) | Option acc. (%) | Parse err. |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 132/132 | 0 | 83.33 | 82.53 | 9 |
| react_r | or-qwen3.6-27b | 132/132 | 0 | 81.82 | 87.35 | 0 |
| graphrag | or-qwen3.6-27b | 132/132 | 0 | 47.73 | 63.25 | 1 |
| recode | or-qwen3.6-27b | 132/132 | 0 | 58.33 | 67.47 | 13 |
| react_c | or-gpt-oss-20b | 132/132 | 0 | 56.06 | 69.58 | 10 |
| react_r | or-gpt-oss-20b | 132/132 | 0 | 51.52 | 62.65 | 19 |
| graphrag | or-gpt-oss-20b | 132/132 | 0 | 15.15 | 32.83 | 30 |
| recode | or-gpt-oss-20b | 132/132 | 0 | 6.82 | 25.00 | 60 |
| react_c | or-gemma-4-31b-think | 132/132 | 0 | 79.55 | 83.43 | 2 |
| react_r | or-gemma-4-31b-think | 132/132 | 0 | 81.06 | 84.04 | 1 |
| graphrag | or-gemma-4-31b-think | 132/132 | 0 | 53.79 | 71.39 | 2 |
| recode | or-gemma-4-31b-think | 132/132 | 0 | 53.79 | 47.89 | 46 |

## Accuracy by question type

Descriptive: accuracy. Others: per-option / per-question.

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 98.04 (n=51) | 100.00 / 100.00 (n=34) | 100.00 / 100.00 (n=12) | 57.14 / 40.00 (n=35) |
| react_r | 100.00 (n=51) | 96.77 / 91.18 (n=34) | 100.00 / 100.00 (n=12) | 71.43 / 40.00 (n=35) |
| graphrag | 76.47 (n=51) | 70.97 / 35.29 (n=34) | 50.00 / 25.00 (n=12) | 53.38 / 25.71 (n=35) |
| recode | 78.43 (n=51) | 76.61 / 47.06 (n=34) | 91.67 / 91.67 (n=12) | 50.38 / 28.57 (n=35) |
| react_c | 92.16 (n=51) | 66.13 / 38.24 (n=34) | 41.67 / 16.67 (n=12) | 69.17 / 34.29 (n=35) |
| react_r | 84.31 (n=51) | 62.10 / 35.29 (n=34) | 54.17 / 16.67 (n=12) | 56.39 / 31.43 (n=35) |
| graphrag | 25.49 (n=51) | 25.81 / 5.88 (n=34) | 54.17 / 8.33 (n=12) | 38.35 / 11.43 (n=35) |
| recode | 5.88 (n=51) | 27.42 / 11.76 (n=34) | 25.00 / 8.33 (n=12) | 30.08 / 2.86 (n=35) |
| react_c | 100.00 (n=51) | 93.55 / 85.29 (n=34) | 100.00 / 100.00 (n=12) | 64.66 / 37.14 (n=35) |
| react_r | 100.00 (n=51) | 94.35 / 88.24 (n=34) | 100.00 / 100.00 (n=12) | 65.41 / 40.00 (n=35) |
| graphrag | 72.55 (n=51) | 91.13 / 79.41 (n=34) | 54.17 / 16.67 (n=12) | 55.64 / 14.29 (n=35) |
| recode | 88.24 (n=51) | 44.35 / 32.35 (n=34) | 58.33 / 58.33 (n=12) | 33.83 / 22.86 (n=35) |

### Question accuracy (%) with 95% bootstrap CI

| System | Model | overall | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 83.3 [77.3, 89.4] | 98.0 [94.1, 100.0] | 100.0 [100.0, 100.0] | 100.0 [100.0, 100.0] | 40.0 [25.6, 57.1] |
| react_r | or-qwen3.6-27b | 81.8 [75.8, 88.6] | 100.0 [100.0, 100.0] | 91.2 [82.3, 100.0] | 100.0 [100.0, 100.0] | 40.0 [22.9, 57.1] |
| graphrag | or-qwen3.6-27b | 47.7 [39.4, 56.1] | 76.5 [64.7, 88.2] | 35.3 [20.6, 50.1] | 25.0 [0.0, 50.0] | 25.7 [11.4, 40.0] |
| recode | or-qwen3.6-27b | 58.3 [50.0, 66.7] | 78.4 [66.7, 88.2] | 47.1 [29.4, 64.7] | 91.7 [75.0, 100.0] | 28.6 [14.3, 42.9] |
| react_c | or-gpt-oss-20b | 56.1 [47.0, 64.4] | 92.2 [84.3, 98.0] | 38.2 [23.5, 55.9] | 16.7 [0.0, 41.7] | 34.3 [20.0, 51.4] |
| react_r | or-gpt-oss-20b | 51.5 [43.2, 59.9] | 84.3 [72.5, 94.1] | 35.3 [17.6, 50.0] | 16.7 [0.0, 41.7] | 31.4 [17.1, 45.7] |
| graphrag | or-gpt-oss-20b | 15.2 [9.1, 21.2] | 25.5 [13.7, 37.2] | 5.9 [0.0, 14.7] | 8.3 [0.0, 25.0] | 11.4 [2.9, 22.9] |
| recode | or-gpt-oss-20b | 6.8 [3.0, 11.4] | 5.9 [0.0, 13.7] | 11.8 [2.9, 23.5] | 8.3 [0.0, 25.0] | 2.9 [0.0, 8.6] |
| react_c | or-gemma-4-31b-think | 79.5 [72.7, 86.4] | 100.0 [100.0, 100.0] | 85.3 [73.5, 97.1] | 100.0 [100.0, 100.0] | 37.1 [22.9, 54.3] |
| react_r | or-gemma-4-31b-think | 81.1 [74.2, 87.1] | 100.0 [100.0, 100.0] | 88.2 [76.5, 97.1] | 100.0 [100.0, 100.0] | 40.0 [25.7, 57.1] |
| graphrag | or-gemma-4-31b-think | 53.8 [45.5, 62.9] | 72.5 [60.8, 84.3] | 79.4 [64.7, 94.1] | 16.7 [0.0, 41.7] | 14.3 [2.9, 25.7] |
| recode | or-gemma-4-31b-think | 53.8 [44.7, 62.1] | 88.2 [78.4, 96.1] | 32.4 [17.6, 47.1] | 58.3 [33.3, 83.3] | 22.9 [8.6, 37.1] |

### Descriptive subtypes (accuracy %)

| System | count | exist | query_color | query_material | query_shape |
|---|---|---|---|---|---|
| react_c | 100.00 | 100.00 | 100.00 | 100.00 | 88.89 |
| react_r | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| graphrag | 64.29 | 90.00 | 60.00 | 87.50 | 88.89 |
| recode | 78.57 | 70.00 | 70.00 | 87.50 | 88.89 |
| react_c | 85.71 | 90.00 | 100.00 | 87.50 | 100.00 |
| react_r | 71.43 | 90.00 | 80.00 | 100.00 | 88.89 |
| graphrag | 35.71 | 30.00 | 20.00 | 25.00 | 11.11 |
| recode | 7.14 | 10.00 | 10.00 | 0.00 | 0.00 |
| react_c | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| react_r | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| graphrag | 71.43 | 80.00 | 50.00 | 87.50 | 77.78 |
| recode | 78.57 | 90.00 | 100.00 | 100.00 | 77.78 |

## Token consumption

Query tokens are per question (mean). Cached input is a subset of input; reasoning is a subset of output. Setup = one-time cost (e.g. PageIndex tree build). Amortized = (setup + all query tokens) / questions answered.

| System | Input | Cached input | Output | Reasoning | Total / q | Setup total | Amortized total / q | Sum (all q) | LLM calls / q | Tool calls / q | Latency / q (s) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| react_c | 14,599.2 | 7,590.5 | 6,468.3 | 5,916.9 | 21,067.5 | 0 | 21,067.5 | 2,780,909 | 5.12 | 0.00 | 285.24 |
| react_r | 12,389.1 | 0.0 | 5,233.8 | 5,044.5 | 17,622.9 | 0 | 17,622.9 | 2,326,222 | 5.23 | 0.00 | 83.76 |
| graphrag | 12,341.1 | 0.0 | 2,283.5 | 2,263.6 | 14,624.5 | 4,712,551 | 50,325.7 | 1,930,439 | 1.00 | 0.00 | 38.61 |
| recode | 24,206.5 | 0.0 | 10,926.4 | 10,147.2 | 35,132.9 | 0 | 35,132.9 | 4,637,545 | 5.00 | 0.00 | 192.51 |
| react_c | 10,025.2 | 6,327.8 | 1,117.6 | 1,043.6 | 11,142.8 | 0 | 11,142.8 | 1,470,845 | 6.09 | 0.00 | 15.87 |
| react_r | 10,630.3 | 6,282.2 | 1,150.3 | 1,072.8 | 11,780.6 | 0 | 11,780.6 | 1,555,040 | 6.94 | 0.00 | 14.89 |
| graphrag | 10,722.9 | 1,072.5 | 800.4 | 847.0 | 11,523.4 | 3,419,183 | 37,426.3 | 1,521,083 | 1.00 | 0.00 | 9.07 |
| recode | 8,198.1 | 6,806.3 | 4,181.1 | 4,132.2 | 12,379.2 | 0 | 12,379.2 | 1,634,053 | 2.20 | 0.00 | 44.14 |
| react_c | 14,211.7 | 8,575.8 | 3,511.4 | 2,561.2 | 17,723.1 | 0 | 17,723.1 | 2,339,453 | 5.75 | 0.00 | 142.88 |
| react_r | 13,074.4 | 7,932.3 | 3,296.2 | 2,451.1 | 16,370.6 | 0 | 16,370.6 | 2,160,916 | 6.08 | 0.00 | 103.92 |
| graphrag | 12,193.0 | 1,013.6 | 1,951.2 | 1,631.0 | 14,144.2 | 2,941,993 | 36,432.0 | 1,867,035 | 1.00 | 0.00 | 48.20 |
| recode | 27,963.8 | 18,995.6 | 9,327.1 | 6,884.7 | 37,290.9 | 0 | 37,290.9 | 4,922,400 | 5.74 | 0.00 | 425.71 |

### Mean total tokens per question, by type

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 12,190.1 | 19,114.8 | 33,398.7 | 31,672.3 |
| react_r | 11,118.5 | 18,407.9 | 20,506.2 | 25,349.7 |
| graphrag | 13,793.0 | 14,785.6 | 14,891.8 | 15,588.1 |
| recode | 32,586.5 | 33,921.4 | 38,127.2 | 38,993.7 |
| react_c | 10,370.4 | 9,102.4 | 10,128.4 | 14,598.0 |
| react_r | 11,548.5 | 9,674.5 | 12,230.7 | 14,010.3 |
| graphrag | 11,402.8 | 11,616.0 | 11,281.2 | 11,692.0 |
| recode | 13,141.9 | 10,388.4 | 12,865.2 | 13,035.1 |
| react_c | 12,153.8 | 16,148.7 | 23,325.5 | 25,447.1 |
| react_r | 10,395.0 | 14,563.5 | 17,527.0 | 26,436.8 |
| graphrag | 13,474.7 | 14,020.4 | 13,896.8 | 15,324.9 |
| recode | 32,014.1 | 38,855.1 | 42,598.5 | 41,640.8 |

### Setup details

- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 9.3s, info: `{"chunks": 186, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "2237726337f8b1ab"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 186, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "40fe3497f1479208"}`
- **graphrag**: 4,712,551 tokens (1,881,167 in / 2,831,384 out, 1086 calls), 2053.4s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d03__or-qwen3.6-27b__ec83bb3c7b01ded3", "index_key": "ec83bb3c7b01ded3", "extraction": {"chunks": 54, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 2053.4, "usage_unknown_calls": 0, "config_hash": "993f8f4f498ff189", "entities": 249, "communities": 67, "llm_seconds": 43068.3}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 186, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "a85015f55f974ee3"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 186, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "10d7c41337847019"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 186, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "d05304d47aafa486"}`
- **graphrag**: 3,419,183 tokens (2,019,837 in / 1,399,346 out, 1424 calls), 1991.4s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d03__or-gpt-oss-20b__bf797a46c4d3afff", "index_key": "bf797a46c4d3afff", "extraction": {"chunks": 54, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 1991.4, "usage_unknown_calls": 0, "config_hash": "2cd5371d9df15cab", "entities": 2725, "communities": 184, "llm_seconds": 13920.6}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 186, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "0622d51cf9caddbb"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 186, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "00e443b1b2e9eb99"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.1s, info: `{"chunks": 186, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "5cdb2503547f526d"}`
- **graphrag**: 2,941,993 tokens (1,802,182 in / 1,139,811 out, 1087 calls), 2192.3s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d03__or-gemma-4-31b-think__0edb22fb16bf3e89", "index_key": "0edb22fb16bf3e89", "extraction": {"chunks": 54, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 2192.3, "usage_unknown_calls": 0, "config_hash": "319ed863e10a70f8", "entities": 300, "communities": 74, "llm_seconds": 28205.9}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 186, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "5f5d068874d5dc93"}`
