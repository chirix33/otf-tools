# CLEVRER document-QA benchmark: e1_d06

- Videos: 20 (validation split, seed None), questions: 149
- Document: `C:\Users\htripathi\PycharmProjects\OTF\otf-tools\implementation-1\runs\e1_d06\document.pdf` (50 pages), rendered from ground-truth annotations (observed 128 frames only; motion log every 8 frames + event frames)
- Descriptive: exact match. Multiple-choice: per-option accuracy, and per-question accuracy (all options of the question correct). Overall question accuracy counts each question once.

## Overall

| System | Model | Answered | Errors | Question acc. (%) | Option acc. (%) | Parse err. |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 149/149 | 0 | 77.85 | 81.74 | 12 |
| react_r | or-qwen3.6-27b | 149/149 | 0 | 78.52 | 86.09 | 0 |
| graphrag | or-qwen3.6-27b | 149/149 | 0 | 44.30 | 62.32 | 2 |
| recode | or-qwen3.6-27b | 149/149 | 0 | 60.40 | 71.01 | 10 |
| react_c | or-gpt-oss-20b | 149/149 | 0 | 47.65 | 61.16 | 21 |
| react_r | or-gpt-oss-20b | 149/149 | 0 | 44.97 | 56.81 | 29 |
| graphrag | or-gpt-oss-20b | 149/149 | 0 | 10.74 | 27.83 | 33 |
| recode | or-gpt-oss-20b | 149/149 | 0 | 5.37 | 25.51 | 66 |
| react_c | or-gemma-4-31b-think | 149/149 | 0 | 79.19 | 85.22 | 0 |
| react_r | or-gemma-4-31b-think | 149/149 | 0 | 79.19 | 84.93 | 1 |
| graphrag | or-gemma-4-31b-think | 149/149 | 0 | 44.30 | 64.06 | 6 |
| recode | or-gemma-4-31b-think | 149/149 | 0 | 50.34 | 44.64 | 57 |

## Accuracy by question type

Descriptive: accuracy. Others: per-option / per-question.

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 93.55 (n=62) | 90.16 / 88.24 (n=34) | 96.88 / 93.75 (n=16) | 64.34 / 35.14 (n=37) |
| react_r | 95.16 (n=62) | 91.80 / 79.41 (n=34) | 100.00 / 100.00 (n=16) | 72.87 / 40.54 (n=37) |
| graphrag | 67.74 (n=62) | 74.59 / 38.24 (n=34) | 37.50 / 25.00 (n=16) | 54.26 / 18.92 (n=37) |
| recode | 72.58 (n=62) | 77.05 / 58.82 (n=34) | 93.75 / 93.75 (n=16) | 58.91 / 27.03 (n=37) |
| react_c | 80.65 (n=62) | 59.02 / 38.24 (n=34) | 43.75 / 12.50 (n=16) | 58.14 / 16.22 (n=37) |
| react_r | 77.42 (n=62) | 61.48 / 41.18 (n=34) | 31.25 / 0.00 (n=16) | 48.84 / 13.51 (n=37) |
| graphrag | 16.13 (n=62) | 27.87 / 14.71 (n=34) | 46.88 / 0.00 (n=16) | 28.68 / 2.70 (n=37) |
| recode | 9.68 (n=62) | 29.51 / 0.00 (n=34) | 25.00 / 0.00 (n=16) | 29.46 / 5.41 (n=37) |
| react_c | 98.39 (n=62) | 92.62 / 82.35 (n=34) | 100.00 / 100.00 (n=16) | 68.22 / 35.14 (n=37) |
| react_r | 98.39 (n=62) | 95.08 / 88.24 (n=34) | 100.00 / 100.00 (n=16) | 65.12 / 29.73 (n=37) |
| graphrag | 58.06 (n=62) | 78.69 / 70.59 (n=34) | 46.88 / 0.00 (n=16) | 57.36 / 16.22 (n=37) |
| recode | 75.81 (n=62) | 46.72 / 41.18 (n=34) | 68.75 / 68.75 (n=16) | 21.71 / 8.11 (n=37) |

### Question accuracy (%) with 95% bootstrap CI

| System | Model | overall | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 77.8 [71.1, 84.6] | 93.5 [87.1, 98.4] | 88.2 [76.5, 97.1] | 93.8 [81.2, 100.0] | 35.1 [21.6, 51.4] |
| react_r | or-qwen3.6-27b | 78.5 [71.8, 85.2] | 95.2 [88.7, 100.0] | 79.4 [64.7, 91.2] | 100.0 [100.0, 100.0] | 40.5 [24.3, 56.8] |
| graphrag | or-qwen3.6-27b | 44.3 [36.9, 52.4] | 67.7 [56.5, 79.0] | 38.2 [20.6, 52.9] | 25.0 [6.2, 43.9] | 18.9 [8.1, 32.4] |
| recode | or-qwen3.6-27b | 60.4 [52.4, 68.5] | 72.6 [61.3, 83.9] | 58.8 [41.2, 76.5] | 93.8 [81.2, 100.0] | 27.0 [13.5, 43.2] |
| react_c | or-gpt-oss-20b | 47.6 [39.6, 55.0] | 80.7 [71.0, 90.3] | 38.2 [23.5, 55.9] | 12.5 [0.0, 31.2] | 16.2 [5.4, 29.7] |
| react_r | or-gpt-oss-20b | 45.0 [36.9, 53.0] | 77.4 [66.1, 87.1] | 41.2 [23.5, 58.8] | 0.0 [0.0, 0.0] | 13.5 [2.7, 24.3] |
| graphrag | or-gpt-oss-20b | 10.7 [6.0, 16.1] | 16.1 [8.1, 25.8] | 14.7 [2.9, 26.5] | 0.0 [0.0, 0.0] | 2.7 [0.0, 8.1] |
| recode | or-gpt-oss-20b | 5.4 [2.0, 9.4] | 9.7 [3.2, 17.7] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] | 5.4 [0.0, 13.5] |
| react_c | or-gemma-4-31b-think | 79.2 [72.5, 85.2] | 98.4 [95.2, 100.0] | 82.3 [67.7, 94.1] | 100.0 [100.0, 100.0] | 35.1 [18.9, 51.4] |
| react_r | or-gemma-4-31b-think | 79.2 [73.2, 85.2] | 98.4 [95.2, 100.0] | 88.2 [76.5, 97.1] | 100.0 [100.0, 100.0] | 29.7 [16.2, 46.0] |
| graphrag | or-gemma-4-31b-think | 44.3 [36.2, 52.4] | 58.1 [45.2, 69.4] | 70.6 [55.9, 85.3] | 0.0 [0.0, 0.0] | 16.2 [5.4, 29.7] |
| recode | or-gemma-4-31b-think | 50.3 [42.3, 58.4] | 75.8 [64.5, 85.5] | 41.2 [26.5, 58.8] | 68.8 [43.8, 93.8] | 8.1 [0.0, 18.9] |

### Descriptive subtypes (accuracy %)

| System | count | exist | query_color | query_material | query_shape |
|---|---|---|---|---|---|
| react_c | 91.30 | 92.31 | 100.00 | 100.00 | 90.00 |
| react_r | 91.30 | 92.31 | 100.00 | 100.00 | 100.00 |
| graphrag | 56.52 | 69.23 | 72.73 | 100.00 | 70.00 |
| recode | 56.52 | 84.62 | 81.82 | 60.00 | 90.00 |
| react_c | 69.57 | 84.62 | 100.00 | 80.00 | 80.00 |
| react_r | 69.57 | 76.92 | 72.73 | 100.00 | 90.00 |
| graphrag | 21.74 | 23.08 | 9.09 | 0.00 | 10.00 |
| recode | 8.70 | 15.38 | 0.00 | 20.00 | 10.00 |
| react_c | 100.00 | 92.31 | 100.00 | 100.00 | 100.00 |
| react_r | 100.00 | 92.31 | 100.00 | 100.00 | 100.00 |
| graphrag | 34.78 | 53.85 | 72.73 | 100.00 | 80.00 |
| recode | 56.52 | 76.92 | 90.91 | 80.00 | 100.00 |

## Token consumption

Query tokens are per question (mean). Cached input is a subset of input; reasoning is a subset of output. Setup = one-time cost (e.g. PageIndex tree build). Amortized = (setup + all query tokens) / questions answered.

| System | Input | Cached input | Output | Reasoning | Total / q | Setup total | Amortized total / q | Sum (all q) | LLM calls / q | Tool calls / q | Latency / q (s) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| react_c | 13,585.6 | 7,035.0 | 6,264.9 | 5,805.9 | 19,850.5 | 0 | 19,850.5 | 2,957,728 | 5.03 | 0.00 | 276.36 |
| react_r | 10,899.4 | 0.0 | 4,687.1 | 4,512.4 | 15,586.4 | 0 | 15,586.4 | 2,322,380 | 4.81 | 0.00 | 74.45 |
| graphrag | 12,426.1 | 0.0 | 2,234.3 | 2,215.6 | 14,660.4 | 4,367,207 | 43,970.6 | 2,184,405 | 1.00 | 0.00 | 39.48 |
| recode | 23,838.7 | 0.0 | 10,477.0 | 9,711.0 | 34,315.7 | 0 | 34,315.7 | 5,113,037 | 5.02 | 0.00 | 194.48 |
| react_c | 9,814.4 | 6,452.6 | 960.1 | 898.4 | 10,774.5 | 0 | 10,774.5 | 1,605,403 | 6.15 | 0.00 | 11.50 |
| react_r | 9,430.7 | 6,043.1 | 881.9 | 797.3 | 10,312.6 | 0 | 10,312.6 | 1,536,584 | 6.68 | 0.00 | 23.00 |
| graphrag | 9,977.1 | 538.6 | 684.3 | 731.9 | 10,661.4 | 2,720,709 | 28,921.2 | 1,588,544 | 1.00 | 0.00 | 6.34 |
| recode | 7,492.9 | 6,127.9 | 3,963.1 | 3,844.9 | 11,456.0 | 0 | 11,456.0 | 1,706,950 | 1.97 | 0.00 | 37.96 |
| react_c | 12,591.2 | 7,962.6 | 3,364.9 | 2,474.9 | 15,956.1 | 0 | 15,956.1 | 2,377,455 | 5.67 | 0.00 | 119.29 |
| react_r | 13,134.2 | 6,731.0 | 3,468.8 | 2,586.5 | 16,603.1 | 0 | 16,603.1 | 2,473,856 | 6.04 | 0.00 | 468.71 |
| graphrag | 12,181.0 | 1,069.0 | 1,801.2 | 1,529.7 | 13,982.2 | 2,681,124 | 31,976.3 | 2,083,348 | 1.00 | 0.00 | 50.59 |
| recode | 28,696.1 | 20,842.0 | 10,320.7 | 7,716.3 | 39,016.8 | 0 | 39,016.8 | 5,813,499 | 6.06 | 0.00 | 521.83 |

### Mean total tokens per question, by type

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 11,995.5 | 19,732.9 | 26,465.4 | 30,260.5 |
| react_r | 10,404.6 | 16,527.3 | 16,887.6 | 22,842.3 |
| graphrag | 13,615.5 | 15,239.7 | 15,232.6 | 15,631.7 |
| recode | 34,797.7 | 34,127.5 | 33,603.2 | 33,989.0 |
| react_c | 10,920.4 | 9,320.1 | 8,851.2 | 12,698.3 |
| react_r | 10,361.5 | 9,419.4 | 11,931.8 | 10,351.4 |
| graphrag | 11,029.4 | 10,426.3 | 10,087.3 | 10,508.9 |
| recode | 13,229.7 | 9,104.6 | 11,531.9 | 10,612.0 |
| react_c | 10,445.6 | 17,139.7 | 20,654.8 | 22,070.3 |
| react_r | 11,663.4 | 15,427.1 | 20,415.2 | 24,312.4 |
| graphrag | 13,460.3 | 14,205.8 | 13,337.6 | 14,930.0 |
| recode | 34,218.5 | 39,210.3 | 48,930.4 | 42,592.4 |

### Setup details

- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 8.1s, info: `{"chunks": 172, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "2237726337f8b1ab"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 172, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "40fe3497f1479208"}`
- **graphrag**: 4,367,207 tokens (1,742,260 in / 2,624,947 out, 995 calls), 5261.0s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d06__or-qwen3.6-27b__30aaec8471aff64a", "index_key": "30aaec8471aff64a", "extraction": {"chunks": 49, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 5261.0, "usage_unknown_calls": 0, "config_hash": "993f8f4f498ff189", "entities": 261, "communities": 75, "llm_seconds": 40072.8}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 172, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "a85015f55f974ee3"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 172, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "10d7c41337847019"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 172, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "d05304d47aafa486"}`
- **graphrag**: 2,720,709 tokens (1,625,908 in / 1,094,801 out, 967 calls), 1429.5s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d06__or-gpt-oss-20b__a12f3f8635cdb558", "index_key": "a12f3f8635cdb558", "extraction": {"chunks": 49, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 1429.5, "usage_unknown_calls": 0, "config_hash": "2cd5371d9df15cab", "entities": 2022, "communities": 139, "llm_seconds": 9057.4}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 172, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "0622d51cf9caddbb"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 172, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "00e443b1b2e9eb99"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 172, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "5cdb2503547f526d"}`
- **graphrag**: 2,681,124 tokens (1,663,038 in / 1,018,086 out, 1019 calls), 1961.9s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d06__or-gemma-4-31b-think__96b769c38e4a9e14", "index_key": "96b769c38e4a9e14", "extraction": {"chunks": 49, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 1961.9, "usage_unknown_calls": 0, "config_hash": "319ed863e10a70f8", "entities": 297, "communities": 75, "llm_seconds": 21585.0}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 172, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "5f5d068874d5dc93"}`
