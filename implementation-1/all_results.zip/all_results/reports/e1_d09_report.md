# CLEVRER document-QA benchmark: e1_d09

- Videos: 20 (validation split, seed None), questions: 147
- Document: `C:\Users\htripathi\PycharmProjects\OTF\otf-tools\implementation-1\runs\e1_d09\document.pdf` (51 pages), rendered from ground-truth annotations (observed 128 frames only; motion log every 8 frames + event frames)
- Descriptive: exact match. Multiple-choice: per-option accuracy, and per-question accuracy (all options of the question correct). Overall question accuracy counts each question once.

## Overall

| System | Model | Answered | Errors | Question acc. (%) | Option acc. (%) | Parse err. |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 147/147 | 0 | 79.59 | 79.55 | 12 |
| react_r | or-qwen3.6-27b | 147/147 | 0 | 78.23 | 86.93 | 0 |
| graphrag | or-qwen3.6-27b | 147/147 | 0 | 41.50 | 63.35 | 3 |
| recode | or-qwen3.6-27b | 147/147 | 0 | 60.54 | 71.31 | 14 |
| react_c | or-gpt-oss-20b | 147/147 | 0 | 51.02 | 61.36 | 14 |
| react_r | or-gpt-oss-20b | 147/147 | 0 | 44.22 | 57.67 | 27 |
| graphrag | or-gpt-oss-20b | 147/147 | 0 | 19.05 | 36.93 | 27 |
| recode | or-gpt-oss-20b | 147/147 | 0 | 12.24 | 29.83 | 73 |
| react_c | or-gemma-4-31b-think | 147/147 | 0 | 77.55 | 82.39 | 2 |
| react_r | or-gemma-4-31b-think | 147/147 | 0 | 78.23 | 83.52 | 1 |
| graphrag | or-gemma-4-31b-think | 147/147 | 0 | 47.62 | 70.74 | 1 |
| recode | or-gemma-4-31b-think | 33/147 | 0 | 36.36 | 36.14 | 14 |

## Accuracy by question type

Descriptive: accuracy. Others: per-option / per-question.

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 100.00 (n=58) | 92.74 / 91.18 (n=34) | 97.06 / 94.12 (n=17) | 54.41 / 31.58 (n=38) |
| react_r | 98.28 (n=58) | 92.74 / 79.41 (n=34) | 100.00 / 100.00 (n=17) | 73.53 / 36.84 (n=38) |
| graphrag | 65.52 (n=58) | 68.55 / 29.41 (n=34) | 50.00 / 35.29 (n=17) | 61.03 / 18.42 (n=38) |
| recode | 77.59 (n=58) | 69.35 / 38.24 (n=34) | 94.12 / 94.12 (n=17) | 64.71 / 39.47 (n=38) |
| react_c | 91.38 (n=58) | 61.29 / 20.59 (n=34) | 58.82 / 41.18 (n=17) | 49.26 / 21.05 (n=38) |
| react_r | 79.31 (n=58) | 55.65 / 26.47 (n=34) | 38.24 / 5.88 (n=17) | 55.15 / 23.68 (n=38) |
| graphrag | 24.14 (n=58) | 37.10 / 20.59 (n=34) | 47.06 / 5.88 (n=17) | 39.71 / 15.79 (n=38) |
| recode | 20.69 (n=58) | 36.29 / 11.76 (n=34) | 23.53 / 11.76 (n=17) | 29.41 / 0.00 (n=38) |
| react_c | 98.28 (n=58) | 85.48 / 64.71 (n=34) | 100.00 / 100.00 (n=17) | 68.38 / 47.37 (n=38) |
| react_r | 100.00 (n=58) | 89.52 / 73.53 (n=34) | 100.00 / 100.00 (n=17) | 66.91 / 39.47 (n=38) |
| graphrag | 53.45 (n=58) | 92.74 / 79.41 (n=34) | 52.94 / 5.88 (n=17) | 62.50 / 28.95 (n=38) |
| recode | 69.23 (n=13) | 44.83 / 12.50 (n=8) | 50.00 / 50.00 (n=2) | 16.22 / 10.00 (n=10) |

### Question accuracy (%) with 95% bootstrap CI

| System | Model | overall | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 79.6 [72.8, 85.7] | 100.0 [100.0, 100.0] | 91.2 [79.4, 100.0] | 94.1 [82.3, 100.0] | 31.6 [18.4, 47.4] |
| react_r | or-qwen3.6-27b | 78.2 [71.4, 85.0] | 98.3 [94.8, 100.0] | 79.4 [64.7, 91.2] | 100.0 [100.0, 100.0] | 36.8 [21.1, 52.6] |
| graphrag | or-qwen3.6-27b | 41.5 [34.0, 49.0] | 65.5 [53.5, 77.6] | 29.4 [14.7, 44.1] | 35.3 [11.8, 58.8] | 18.4 [7.9, 31.6] |
| recode | or-qwen3.6-27b | 60.5 [52.4, 68.7] | 77.6 [67.2, 87.9] | 38.2 [20.6, 55.9] | 94.1 [82.3, 100.0] | 39.5 [23.7, 55.3] |
| react_c | or-gpt-oss-20b | 51.0 [42.9, 59.2] | 91.4 [84.5, 98.3] | 20.6 [8.8, 35.3] | 41.2 [17.6, 64.7] | 21.1 [7.9, 34.2] |
| react_r | or-gpt-oss-20b | 44.2 [36.0, 52.4] | 79.3 [69.0, 88.0] | 26.5 [11.8, 41.2] | 5.9 [0.0, 17.6] | 23.7 [10.5, 36.8] |
| graphrag | or-gpt-oss-20b | 19.1 [12.9, 25.9] | 24.1 [13.8, 34.5] | 20.6 [8.8, 35.3] | 5.9 [0.0, 17.6] | 15.8 [5.3, 28.9] |
| recode | or-gpt-oss-20b | 12.2 [7.5, 17.7] | 20.7 [12.1, 31.0] | 11.8 [2.9, 23.5] | 11.8 [0.0, 29.4] | 0.0 [0.0, 0.0] |
| react_c | or-gemma-4-31b-think | 77.5 [70.8, 83.7] | 98.3 [94.8, 100.0] | 64.7 [50.0, 79.4] | 100.0 [100.0, 100.0] | 47.4 [31.6, 63.2] |
| react_r | or-gemma-4-31b-think | 78.2 [71.4, 85.0] | 100.0 [100.0, 100.0] | 73.5 [58.8, 88.2] | 100.0 [100.0, 100.0] | 39.5 [23.7, 55.3] |
| graphrag | or-gemma-4-31b-think | 47.6 [39.5, 55.8] | 53.5 [41.4, 65.5] | 79.4 [64.7, 91.2] | 5.9 [0.0, 17.6] | 28.9 [15.8, 44.7] |
| recode | or-gemma-4-31b-think | 36.4 [21.2, 54.5] | 69.2 [46.1, 92.3] | 12.5 [0.0, 37.5] | 50.0 [0.0, 100.0] | 10.0 [0.0, 30.0] |

### Descriptive subtypes (accuracy %)

| System | count | exist | query_color | query_material | query_shape |
|---|---|---|---|---|---|
| react_c | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| react_r | 96.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| graphrag | 56.00 | 77.78 | 57.14 | 80.00 | 71.43 |
| recode | 80.00 | 77.78 | 71.43 | 80.00 | 71.43 |
| react_c | 88.00 | 77.78 | 100.00 | 100.00 | 100.00 |
| react_r | 84.00 | 66.67 | 57.14 | 90.00 | 85.71 |
| graphrag | 28.00 | 33.33 | 0.00 | 30.00 | 14.29 |
| recode | 20.00 | 33.33 | 14.29 | 20.00 | 14.29 |
| react_c | 100.00 | 100.00 | 85.71 | 100.00 | 100.00 |
| react_r | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| graphrag | 40.00 | 77.78 | 42.86 | 60.00 | 71.43 |
| recode | 40.00 | 100.00 | 100.00 | 100.00 | 0.00 |

## Token consumption

Query tokens are per question (mean). Cached input is a subset of input; reasoning is a subset of output. Setup = one-time cost (e.g. PageIndex tree build). Amortized = (setup + all query tokens) / questions answered.

| System | Input | Cached input | Output | Reasoning | Total / q | Setup total | Amortized total / q | Sum (all q) | LLM calls / q | Tool calls / q | Latency / q (s) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| react_c | 14,986.6 | 7,989.3 | 6,950.5 | 6,385.1 | 21,937.1 | 0 | 21,937.1 | 3,224,754 | 5.22 | 0.00 | 304.66 |
| react_r | 11,212.4 | 0.0 | 5,083.4 | 4,903.5 | 16,295.7 | 0 | 16,295.7 | 2,395,475 | 4.90 | 0.00 | 84.06 |
| graphrag | 11,932.4 | 0.0 | 2,391.5 | 2,372.3 | 14,324.0 | 4,501,076 | 44,943.5 | 2,105,622 | 1.00 | 0.00 | 40.82 |
| recode | 24,241.6 | 0.0 | 11,031.7 | 10,255.9 | 35,273.3 | 0 | 35,273.3 | 5,185,168 | 5.09 | 0.00 | 184.97 |
| react_c | 9,690.7 | 6,273.7 | 1,051.4 | 1,001.8 | 10,742.1 | 0 | 10,742.1 | 1,579,092 | 5.99 | 0.00 | 12.95 |
| react_r | 9,816.5 | 6,008.2 | 981.9 | 908.8 | 10,798.4 | 0 | 10,798.4 | 1,587,361 | 6.57 | 0.00 | 15.36 |
| graphrag | 10,923.7 | 1,518.4 | 972.1 | 1,039.0 | 11,895.8 | 2,985,904 | 32,208.1 | 1,748,686 | 1.00 | 0.00 | 18.58 |
| recode | 7,595.4 | 6,385.9 | 4,083.7 | 3,982.5 | 11,679.1 | 0 | 11,679.1 | 1,716,823 | 2.01 | 0.00 | 32.18 |
| react_c | 13,430.2 | 7,683.1 | 3,774.7 | 2,763.6 | 17,204.9 | 0 | 17,204.9 | 2,529,119 | 5.71 | 0.00 | 118.00 |
| react_r | 12,428.7 | 7,273.8 | 3,212.0 | 2,398.8 | 15,640.7 | 0 | 15,640.7 | 2,299,187 | 5.97 | 0.00 | 209.06 |
| graphrag | 12,206.4 | 1,043.6 | 2,011.2 | 1,668.5 | 14,217.7 | 2,734,419 | 32,819.1 | 2,089,995 | 1.00 | 0.00 | 56.89 |
| recode | 31,085.0 | 21,848.2 | 9,813.8 | 7,207.1 | 40,898.8 | 0 | 40,898.8 | 1,349,659 | 6.42 | 0.00 | 560.90 |

### Mean total tokens per question, by type

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 11,970.8 | 23,166.0 | 32,231.9 | 31,443.7 |
| react_r | 10,614.3 | 16,479.9 | 17,787.9 | 24,135.1 |
| graphrag | 13,515.8 | 14,134.5 | 14,747.5 | 15,537.4 |
| recode | 35,292.6 | 33,757.8 | 35,665.2 | 36,424.4 |
| react_c | 10,526.6 | 9,074.7 | 10,988.5 | 12,452.7 |
| react_r | 10,676.6 | 9,391.8 | 11,861.1 | 11,767.3 |
| graphrag | 11,500.8 | 11,830.4 | 12,283.2 | 12,383.9 |
| recode | 12,013.9 | 10,362.7 | 11,086.3 | 12,611.0 |
| react_c | 11,063.8 | 15,303.2 | 21,175.8 | 26,503.2 |
| react_r | 10,918.7 | 13,238.5 | 18,310.4 | 23,803.1 |
| graphrag | 13,769.1 | 14,020.6 | 13,909.1 | 15,216.6 |
| recode | 38,858.3 | 36,725.1 | 61,630.5 | 42,743.9 |

### Setup details

- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 7.6s, info: `{"chunks": 175, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "2237726337f8b1ab"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 175, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "40fe3497f1479208"}`
- **graphrag**: 4,501,076 tokens (1,773,442 in / 2,727,634 out, 1055 calls), 2256.4s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d09__or-qwen3.6-27b__cec4021b13b08153", "index_key": "cec4021b13b08153", "extraction": {"chunks": 50, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 2256.4, "usage_unknown_calls": 0, "config_hash": "993f8f4f498ff189", "entities": 242, "communities": 61, "llm_seconds": 42499.9}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 175, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "a85015f55f974ee3"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 175, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "10d7c41337847019"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 175, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "d05304d47aafa486"}`
- **graphrag**: 2,985,904 tokens (1,758,972 in / 1,226,932 out, 1024 calls), 1414.3s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d09__or-gpt-oss-20b__8e3e84872155eab1", "index_key": "8e3e84872155eab1", "extraction": {"chunks": 50, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 1414.3, "usage_unknown_calls": 0, "config_hash": "2cd5371d9df15cab", "entities": 2108, "communities": 198, "llm_seconds": 8576.3}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 175, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "0622d51cf9caddbb"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 175, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "00e443b1b2e9eb99"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 175, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "5cdb2503547f526d"}`
- **graphrag**: 2,734,419 tokens (1,695,583 in / 1,038,836 out, 1007 calls), 2477.1s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d09__or-gemma-4-31b-think__d8c5b7c13860935e", "index_key": "d8c5b7c13860935e", "extraction": {"chunks": 50, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 2477.1, "usage_unknown_calls": 0, "config_hash": "319ed863e10a70f8", "entities": 318, "communities": 81, "llm_seconds": 27866.6}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 175, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "5f5d068874d5dc93"}`
