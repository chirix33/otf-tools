# CLEVRER document-QA benchmark: e1_d12

- Videos: 20 (validation split, seed None), questions: 124
- Document: `C:\Users\htripathi\PycharmProjects\OTF\otf-tools\implementation-1\runs\e1_d12\document.pdf` (53 pages), rendered from ground-truth annotations (observed 128 frames only; motion log every 8 frames + event frames)
- Descriptive: exact match. Multiple-choice: per-option accuracy, and per-question accuracy (all options of the question correct). Overall question accuracy counts each question once.

## Overall

| System | Model | Answered | Errors | Question acc. (%) | Option acc. (%) | Parse err. |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 124/124 | 0 | 79.03 | 82.69 | 8 |
| react_r | or-qwen3.6-27b | 124/124 | 0 | 75.00 | 83.33 | 2 |
| graphrag | or-qwen3.6-27b | 124/124 | 0 | 49.19 | 61.86 | 4 |
| recode | or-qwen3.6-27b | 124/124 | 0 | 58.87 | 69.55 | 14 |
| react_c | or-gpt-oss-20b | 124/124 | 0 | 53.23 | 68.91 | 8 |
| react_r | or-gpt-oss-20b | 124/124 | 0 | 50.81 | 63.14 | 19 |
| graphrag | or-gpt-oss-20b | 124/124 | 0 | 20.16 | 37.82 | 24 |
| recode | or-gpt-oss-20b | 124/124 | 0 | 8.06 | 25.00 | 65 |
| react_c | or-gemma-4-31b-think | 124/124 | 0 | 79.84 | 86.22 | 0 |
| react_r | or-gemma-4-31b-think | 124/124 | 0 | 76.61 | 84.29 | 0 |

## Accuracy by question type

Descriptive: accuracy. Others: per-option / per-question.

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 97.83 (n=46) | 89.57 / 83.87 (n=31) | 90.91 / 90.91 (n=11) | 69.77 / 47.22 (n=36) |
| react_r | 95.65 (n=46) | 91.30 / 74.19 (n=31) | 100.00 / 100.00 (n=11) | 68.99 / 41.67 (n=36) |
| graphrag | 80.43 (n=46) | 73.04 / 41.94 (n=31) | 27.27 / 18.18 (n=11) | 51.16 / 25.00 (n=36) |
| recode | 76.09 (n=46) | 77.39 / 54.84 (n=31) | 100.00 / 100.00 (n=11) | 55.04 / 27.78 (n=36) |
| react_c | 82.61 (n=46) | 65.22 / 35.48 (n=31) | 54.55 / 18.18 (n=11) | 69.77 / 41.67 (n=36) |
| react_r | 82.61 (n=46) | 54.78 / 25.81 (n=31) | 54.55 / 36.36 (n=11) | 65.12 / 36.11 (n=36) |
| graphrag | 32.61 (n=46) | 41.74 / 22.58 (n=31) | 54.55 / 9.09 (n=11) | 33.33 / 5.56 (n=36) |
| recode | 15.22 (n=46) | 32.17 / 9.68 (n=31) | 31.82 / 0.00 (n=11) | 20.93 / 0.00 (n=36) |
| react_c | 100.00 (n=46) | 89.57 / 74.19 (n=31) | 100.00 / 100.00 (n=11) | 75.97 / 52.78 (n=36) |
| react_r | 97.83 (n=46) | 93.04 / 83.87 (n=31) | 90.91 / 90.91 (n=11) | 70.54 / 38.89 (n=36) |

### Question accuracy (%) with 95% bootstrap CI

| System | Model | overall | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 79.0 [71.8, 86.3] | 97.8 [93.5, 100.0] | 83.9 [71.0, 96.8] | 90.9 [72.7, 100.0] | 47.2 [30.6, 63.9] |
| react_r | or-qwen3.6-27b | 75.0 [66.9, 82.3] | 95.7 [89.1, 100.0] | 74.2 [58.1, 87.1] | 100.0 [100.0, 100.0] | 41.7 [27.8, 58.3] |
| graphrag | or-qwen3.6-27b | 49.2 [40.3, 58.1] | 80.4 [67.4, 91.3] | 41.9 [25.8, 58.1] | 18.2 [0.0, 45.5] | 25.0 [11.1, 38.9] |
| recode | or-qwen3.6-27b | 58.9 [50.0, 67.7] | 76.1 [63.0, 87.0] | 54.8 [38.7, 71.0] | 100.0 [100.0, 100.0] | 27.8 [13.9, 44.4] |
| react_c | or-gpt-oss-20b | 53.2 [44.4, 62.1] | 82.6 [71.7, 93.5] | 35.5 [19.4, 51.6] | 18.2 [0.0, 45.5] | 41.7 [25.0, 55.6] |
| react_r | or-gpt-oss-20b | 50.8 [42.7, 59.7] | 82.6 [69.6, 93.5] | 25.8 [12.9, 41.9] | 36.4 [9.1, 63.6] | 36.1 [19.4, 50.0] |
| graphrag | or-gpt-oss-20b | 20.2 [12.9, 27.4] | 32.6 [19.6, 45.6] | 22.6 [9.7, 38.7] | 9.1 [0.0, 27.3] | 5.6 [0.0, 13.9] |
| recode | or-gpt-oss-20b | 8.1 [3.2, 13.7] | 15.2 [6.5, 26.1] | 9.7 [0.0, 22.6] | 0.0 [0.0, 0.0] | 0.0 [0.0, 0.0] |
| react_c | or-gemma-4-31b-think | 79.8 [72.6, 86.3] | 100.0 [100.0, 100.0] | 74.2 [58.1, 90.3] | 100.0 [100.0, 100.0] | 52.8 [36.1, 69.4] |
| react_r | or-gemma-4-31b-think | 76.6 [68.5, 83.9] | 97.8 [93.5, 100.0] | 83.9 [71.0, 96.8] | 90.9 [72.7, 100.0] | 38.9 [22.2, 55.6] |

### Descriptive subtypes (accuracy %)

| System | count | exist | query_color | query_material | query_shape |
|---|---|---|---|---|---|
| react_c | 95.45 | 100.00 | 100.00 | 100.00 | 100.00 |
| react_r | 90.91 | 100.00 | 100.00 | 100.00 | 100.00 |
| graphrag | 72.73 | 71.43 | 85.71 | 100.00 | 100.00 |
| recode | 63.64 | 71.43 | 100.00 | 100.00 | 85.71 |
| react_c | 81.82 | 85.71 | 85.71 | 100.00 | 71.43 |
| react_r | 81.82 | 100.00 | 57.14 | 66.67 | 100.00 |
| graphrag | 22.73 | 71.43 | 28.57 | 66.67 | 14.29 |
| recode | 13.64 | 28.57 | 0.00 | 0.00 | 28.57 |
| react_c | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| react_r | 95.45 | 100.00 | 100.00 | 100.00 | 100.00 |

## Token consumption

Query tokens are per question (mean). Cached input is a subset of input; reasoning is a subset of output. Setup = one-time cost (e.g. PageIndex tree build). Amortized = (setup + all query tokens) / questions answered.

| System | Input | Cached input | Output | Reasoning | Total / q | Setup total | Amortized total / q | Sum (all q) | LLM calls / q | Tool calls / q | Latency / q (s) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| react_c | 13,525.0 | 7,018.1 | 6,528.9 | 6,165.0 | 20,053.9 | 0 | 20,053.9 | 2,486,681 | 5.03 | 0.00 | 286.73 |
| react_r | 11,036.3 | 0.0 | 4,920.7 | 4,745.6 | 15,957.1 | 0 | 15,957.1 | 1,978,675 | 4.81 | 0.00 | 78.34 |
| graphrag | 12,066.3 | 0.0 | 2,366.4 | 2,346.8 | 14,432.7 | 4,462,617 | 50,421.6 | 1,789,657 | 1.00 | 0.00 | 55.16 |
| recode | 23,455.5 | 0.0 | 10,561.2 | 9,811.6 | 34,016.7 | 0 | 34,016.7 | 4,218,068 | 4.93 | 0.00 | 179.19 |
| react_c | 9,593.4 | 5,979.1 | 1,016.4 | 944.9 | 10,609.9 | 0 | 10,609.9 | 1,315,624 | 5.78 | 0.00 | 12.03 |
| react_r | 9,647.3 | 6,136.0 | 1,088.1 | 1,016.3 | 10,735.3 | 0 | 10,735.3 | 1,331,183 | 6.76 | 0.00 | 15.87 |
| graphrag | 10,740.2 | 1,320.0 | 968.0 | 1,030.5 | 11,708.2 | 2,801,116 | 34,297.9 | 1,451,822 | 1.00 | 0.00 | 7.93 |
| recode | 8,135.8 | 6,939.6 | 4,255.0 | 4,170.6 | 12,390.8 | 0 | 12,390.8 | 1,536,455 | 2.21 | 0.00 | 33.51 |
| react_c | 13,113.2 | 7,705.8 | 4,119.8 | 3,059.7 | 17,233.0 | 0 | 17,233.0 | 2,136,896 | 5.73 | 0.00 | 119.53 |
| react_r | 12,847.8 | 7,255.1 | 3,809.4 | 2,841.3 | 16,657.2 | 0 | 16,657.2 | 2,065,488 | 5.93 | 0.00 | 164.35 |

### Mean total tokens per question, by type

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 11,899.3 | 22,043.9 | 22,727.7 | 27,942.9 |
| react_r | 10,271.8 | 18,146.1 | 18,277.3 | 20,627.6 |
| graphrag | 13,676.3 | 14,780.6 | 14,363.9 | 15,120.7 |
| recode | 33,895.4 | 33,008.2 | 32,460.9 | 35,515.4 |
| react_c | 10,367.8 | 8,477.9 | 13,617.4 | 11,836.1 |
| react_r | 9,796.4 | 8,639.6 | 13,477.4 | 12,901.9 |
| graphrag | 11,607.8 | 11,558.6 | 11,968.7 | 11,885.8 |
| recode | 12,700.8 | 14,876.0 | 10,451.5 | 10,447.1 |
| react_c | 9,831.2 | 17,585.0 | 20,638.2 | 25,347.4 |
| react_r | 11,223.5 | 16,323.0 | 20,937.9 | 22,580.0 |

### Setup details

- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 8.1s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "2237726337f8b1ab"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "40fe3497f1479208"}`
- **graphrag**: 4,462,617 tokens (1,798,445 in / 2,664,172 out, 994 calls), 5473.0s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d12__or-qwen3.6-27b__5a2b3ece33dde194", "index_key": "5a2b3ece33dde194", "extraction": {"chunks": 52, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 5473.0, "usage_unknown_calls": 0, "config_hash": "993f8f4f498ff189", "entities": 257, "communities": 66, "llm_seconds": 41199.1}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "a85015f55f974ee3"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "10d7c41337847019"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "d05304d47aafa486"}`
- **graphrag**: 2,801,116 tokens (1,662,608 in / 1,138,508 out, 919 calls), 1008.1s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d12__or-gpt-oss-20b__ff9def752a6d50f5", "index_key": "ff9def752a6d50f5", "extraction": {"chunks": 52, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 1008.1, "usage_unknown_calls": 0, "config_hash": "2cd5371d9df15cab", "entities": 2529, "communities": 167, "llm_seconds": 6400.0}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "0622d51cf9caddbb"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "00e443b1b2e9eb99"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "5cdb2503547f526d"}`
