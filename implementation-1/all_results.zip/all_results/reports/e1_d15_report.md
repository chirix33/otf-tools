# CLEVRER document-QA benchmark: e1_d15

- Videos: 20 (validation split, seed None), questions: 142
- Document: `C:\Users\htripathi\PycharmProjects\OTF\otf-tools\implementation-1\runs\e1_d15\document.pdf` (55 pages), rendered from ground-truth annotations (observed 128 frames only; motion log every 8 frames + event frames)
- Descriptive: exact match. Multiple-choice: per-option accuracy, and per-question accuracy (all options of the question correct). Overall question accuracy counts each question once.

## Overall

| System | Model | Answered | Errors | Question acc. (%) | Option acc. (%) | Parse err. |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 142/142 | 0 | 85.21 | 87.25 | 7 |
| react_r | or-qwen3.6-27b | 142/142 | 0 | 82.39 | 88.39 | 2 |
| graphrag | or-qwen3.6-27b | 142/142 | 0 | 50.70 | 66.29 | 3 |
| recode | or-qwen3.6-27b | 142/142 | 0 | 61.27 | 69.97 | 19 |
| react_c | or-gpt-oss-20b | 142/142 | 0 | 54.93 | 68.27 | 18 |
| react_r | or-gpt-oss-20b | 142/142 | 0 | 46.48 | 55.81 | 30 |
| graphrag | or-gpt-oss-20b | 142/142 | 0 | 16.20 | 29.75 | 37 |
| recode | or-gpt-oss-20b | 142/142 | 0 | 14.08 | 29.75 | 59 |
| react_c | or-gemma-4-31b-think | 142/142 | 0 | 83.10 | 87.54 | 0 |
| react_r | or-gemma-4-31b-think | 142/142 | 0 | 83.80 | 88.95 | 0 |

## Accuracy by question type

Descriptive: accuracy. Others: per-option / per-question.

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 96.30 (n=54) | 96.95 / 94.59 (n=37) | 100.00 / 100.00 (n=12) | 72.92 / 56.41 (n=39) |
| react_r | 98.15 (n=54) | 93.13 / 86.49 (n=37) | 100.00 / 100.00 (n=12) | 78.47 / 51.28 (n=39) |
| graphrag | 74.07 (n=54) | 83.21 / 62.16 (n=37) | 45.83 / 25.00 (n=12) | 51.39 / 15.38 (n=39) |
| recode | 70.37 (n=54) | 80.15 / 64.86 (n=37) | 91.67 / 91.67 (n=12) | 56.94 / 35.90 (n=39) |
| react_c | 81.48 (n=54) | 73.28 / 45.95 (n=37) | 50.00 / 25.00 (n=12) | 61.81 / 35.90 (n=39) |
| react_r | 77.78 (n=54) | 45.04 / 27.03 (n=37) | 37.50 / 8.33 (n=12) | 60.42 / 33.33 (n=39) |
| graphrag | 25.93 (n=54) | 31.30 / 16.22 (n=37) | 45.83 / 8.33 (n=12) | 27.08 / 5.13 (n=39) |
| recode | 24.07 (n=54) | 35.88 / 8.11 (n=37) | 25.00 / 8.33 (n=12) | 27.08 / 7.69 (n=39) |
| react_c | 98.15 (n=54) | 94.66 / 89.19 (n=37) | 100.00 / 100.00 (n=12) | 75.00 / 51.28 (n=39) |
| react_r | 98.15 (n=54) | 96.18 / 91.89 (n=37) | 100.00 / 100.00 (n=12) | 77.08 / 51.28 (n=39) |

### Question accuracy (%) with 95% bootstrap CI

| System | Model | overall | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 85.2 [78.9, 90.8] | 96.3 [90.7, 100.0] | 94.6 [86.5, 100.0] | 100.0 [100.0, 100.0] | 56.4 [41.0, 71.8] |
| react_r | or-qwen3.6-27b | 82.4 [76.1, 88.7] | 98.2 [94.4, 100.0] | 86.5 [75.7, 97.3] | 100.0 [100.0, 100.0] | 51.3 [35.9, 66.7] |
| graphrag | or-qwen3.6-27b | 50.7 [42.2, 59.1] | 74.1 [61.1, 85.2] | 62.2 [46.0, 78.4] | 25.0 [0.0, 50.0] | 15.4 [5.1, 25.6] |
| recode | or-qwen3.6-27b | 61.3 [53.5, 69.0] | 70.4 [57.4, 81.5] | 64.9 [48.6, 78.4] | 91.7 [75.0, 100.0] | 35.9 [20.5, 51.3] |
| react_c | or-gpt-oss-20b | 54.9 [47.2, 63.4] | 81.5 [70.4, 90.7] | 46.0 [29.7, 62.2] | 25.0 [0.0, 50.0] | 35.9 [20.5, 51.3] |
| react_r | or-gpt-oss-20b | 46.5 [38.0, 54.2] | 77.8 [66.7, 88.9] | 27.0 [13.5, 40.5] | 8.3 [0.0, 25.0] | 33.3 [20.5, 48.7] |
| graphrag | or-gpt-oss-20b | 16.2 [10.6, 22.5] | 25.9 [14.8, 37.0] | 16.2 [5.4, 29.7] | 8.3 [0.0, 25.0] | 5.1 [0.0, 12.8] |
| recode | or-gpt-oss-20b | 14.1 [8.4, 19.7] | 24.1 [13.0, 35.2] | 8.1 [0.0, 18.9] | 8.3 [0.0, 25.0] | 7.7 [0.0, 17.9] |
| react_c | or-gemma-4-31b-think | 83.1 [76.8, 88.7] | 98.2 [94.4, 100.0] | 89.2 [78.4, 97.3] | 100.0 [100.0, 100.0] | 51.3 [35.9, 66.7] |
| react_r | or-gemma-4-31b-think | 83.8 [77.5, 89.4] | 98.2 [94.4, 100.0] | 91.9 [81.1, 100.0] | 100.0 [100.0, 100.0] | 51.3 [35.9, 66.7] |

### Descriptive subtypes (accuracy %)

| System | count | exist | query_color | query_material | query_shape |
|---|---|---|---|---|---|
| react_c | 100.00 | 91.67 | 90.00 | 100.00 | 100.00 |
| react_r | 100.00 | 91.67 | 100.00 | 100.00 | 100.00 |
| graphrag | 70.00 | 83.33 | 80.00 | 66.67 | 66.67 |
| recode | 65.00 | 75.00 | 80.00 | 33.33 | 77.78 |
| react_c | 90.00 | 75.00 | 80.00 | 66.67 | 77.78 |
| react_r | 90.00 | 66.67 | 70.00 | 66.67 | 77.78 |
| graphrag | 30.00 | 25.00 | 20.00 | 66.67 | 11.11 |
| recode | 15.00 | 50.00 | 20.00 | 33.33 | 11.11 |
| react_c | 100.00 | 91.67 | 100.00 | 100.00 | 100.00 |
| react_r | 100.00 | 91.67 | 100.00 | 100.00 | 100.00 |

## Token consumption

Query tokens are per question (mean). Cached input is a subset of input; reasoning is a subset of output. Setup = one-time cost (e.g. PageIndex tree build). Amortized = (setup + all query tokens) / questions answered.

| System | Input | Cached input | Output | Reasoning | Total / q | Setup total | Amortized total / q | Sum (all q) | LLM calls / q | Tool calls / q | Latency / q (s) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| react_c | 14,669.2 | 7,718.5 | 6,216.3 | 5,738.6 | 20,885.5 | 0 | 20,885.5 | 2,965,743 | 5.17 | 0.00 | 275.91 |
| react_r | 11,926.5 | 0.0 | 5,795.8 | 5,610.1 | 17,722.2 | 0 | 17,722.2 | 2,516,557 | 5.15 | 0.00 | 89.32 |
| graphrag | 12,369.4 | 0.0 | 2,327.2 | 2,307.6 | 14,696.6 | 4,622,511 | 47,249.5 | 2,086,914 | 1.00 | 0.00 | 39.96 |
| recode | 24,671.4 | 0.0 | 11,701.4 | 10,893.1 | 36,372.8 | 0 | 36,372.8 | 5,164,933 | 5.20 | 0.00 | 206.83 |
| react_c | 9,838.6 | 6,154.1 | 967.1 | 894.8 | 10,805.7 | 0 | 10,805.7 | 1,534,412 | 5.78 | 0.00 | 13.12 |
| react_r | 10,784.6 | 6,773.2 | 1,076.0 | 983.9 | 11,860.6 | 0 | 11,860.6 | 1,684,204 | 7.32 | 0.00 | 16.86 |
| graphrag | 10,416.6 | 1,195.3 | 955.2 | 1,004.4 | 11,371.8 | 3,441,536 | 35,608.0 | 1,614,794 | 1.00 | 0.00 | 6.01 |
| recode | 6,435.1 | 5,183.8 | 3,567.2 | 3,442.9 | 10,002.3 | 0 | 10,002.3 | 1,420,324 | 1.65 | 0.00 | 31.02 |
| react_c | 14,007.4 | 8,356.6 | 3,605.7 | 2,668.5 | 17,613.0 | 0 | 17,613.0 | 2,501,051 | 5.75 | 0.00 | 115.94 |
| react_r | 12,538.7 | 7,306.4 | 3,184.1 | 2,364.0 | 15,722.7 | 0 | 15,722.7 | 2,232,628 | 5.99 | 0.00 | 90.63 |

### Mean total tokens per question, by type

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 12,168.1 | 18,247.8 | 32,924.2 | 31,754.0 |
| react_r | 11,540.3 | 18,194.5 | 18,277.1 | 25,663.2 |
| graphrag | 13,977.7 | 14,644.4 | 14,939.6 | 15,666.7 |
| recode | 37,289.4 | 35,090.0 | 29,953.6 | 38,295.6 |
| react_c | 11,079.2 | 9,225.6 | 11,302.6 | 11,773.3 |
| react_r | 11,160.5 | 10,136.5 | 16,345.7 | 13,085.6 |
| graphrag | 11,191.4 | 11,388.0 | 11,894.7 | 11,445.3 |
| recode | 11,226.4 | 8,505.2 | 9,960.2 | 9,740.6 |
| react_c | 13,027.6 | 15,145.9 | 18,510.4 | 26,026.6 |
| react_r | 12,999.4 | 14,416.9 | 17,557.4 | 20,167.9 |

### Setup details

- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 7.5s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "2237726337f8b1ab"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "40fe3497f1479208"}`
- **graphrag**: 4,622,511 tokens (1,836,633 in / 2,785,878 out, 1071 calls), 5688.3s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d15__or-qwen3.6-27b__5a1ca1f5e065c288", "index_key": "5a1ca1f5e065c288", "extraction": {"chunks": 52, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 5688.3, "usage_unknown_calls": 0, "config_hash": "993f8f4f498ff189", "entities": 256, "communities": 70, "llm_seconds": 42938.8}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "a85015f55f974ee3"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "10d7c41337847019"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "d05304d47aafa486"}`
- **graphrag**: 3,441,536 tokens (2,032,677 in / 1,408,859 out, 1410 calls), 1264.0s, info: `{"index_method": "standard", "index_dir": "C:\\Users\\htripathi\\PycharmProjects\\OTF\\otf-tools\\implementation-1\\runs\\tier_b\\graphrag_index\\e1_d15__or-gpt-oss-20b__95eac05ccc7d65e5", "index_key": "95eac05ccc7d65e5", "extraction": {"chunks": 52, "failed_chunks": 0, "failed_fraction": 0.0, "empty_but_completed_chunks": 0, "meter_version": 2}, "index_build_s": 1264.0, "usage_unknown_calls": 0, "config_hash": "2cd5371d9df15cab", "entities": 2121, "communities": 233, "llm_seconds": 8691.6}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "max_depth": 6, "usage_unknown_calls": 0, "config_hash": "0622d51cf9caddbb"}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "00e443b1b2e9eb99"}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.0s, info: `{"chunks": 180, "embed_model": "BAAI/bge-small-en-v1.5", "top_k": 5, "nodes": 81, "usage_unknown_calls": 0, "config_hash": "5cdb2503547f526d"}`
