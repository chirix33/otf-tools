# CLEVRER document-QA benchmark: e1 (5 documents)

- Videos: 100 (validation split, seed None), questions: 694
- Document: `e1_d03 .. e1_d15` (265 pages), rendered from ground-truth annotations (observed 128 frames only; motion log every 8 frames + event frames)
- Descriptive: exact match. Multiple-choice: per-option accuracy, and per-question accuracy (all options of the question correct). Overall question accuracy counts each question once.

## Overall

| System | Model | Answered | Errors | Question acc. (%) | Option acc. (%) | Parse err. |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 694/694 | 0 | 80.98 | 82.76 | 48 |
| react_r | or-qwen3.6-27b | 694/694 | 0 | 79.25 | 86.48 | 4 |
| graphrag | or-qwen3.6-27b | 694/694 | 0 | 46.54 | 63.46 | 13 |
| recode | or-qwen3.6-27b | 694/694 | 0 | 59.94 | 69.89 | 70 |
| react_c | or-gpt-oss-20b | 694/694 | 0 | 52.45 | 65.76 | 71 |
| react_r | or-gpt-oss-20b | 694/694 | 0 | 47.41 | 59.09 | 124 |
| graphrag | or-gpt-oss-20b | 694/694 | 0 | 16.14 | 32.94 | 151 |
| recode | or-gpt-oss-20b | 694/694 | 0 | 9.37 | 27.10 | 323 |
| react_c | or-gemma-4-31b-think | 694/694 | 0 | 79.83 | 84.95 | 4 |
| react_r | or-gemma-4-31b-think | 694/694 | 0 | 79.83 | 85.18 | 3 |

## Accuracy by question type

Descriptive: accuracy. Others: per-option / per-question.

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 97.05 (n=271) | 93.99 / 91.76 (n=170) | 97.06 / 95.59 (n=68) | 63.79 / 42.16 (n=185) |
| react_r | 97.42 (n=271) | 93.18 / 82.35 (n=170) | 100.00 / 100.00 (n=68) | 73.17 / 42.16 (n=185) |
| graphrag | 72.32 (n=271) | 74.19 / 41.76 (n=170) | 42.65 / 26.47 (n=68) | 54.25 / 20.54 (n=185) |
| recode | 74.91 (n=271) | 76.14 / 52.94 (n=170) | 94.12 / 94.12 (n=68) | 57.23 / 31.89 (n=185) |
| react_c | 85.61 (n=271) | 65.10 / 35.88 (n=170) | 50.00 / 23.53 (n=68) | 61.55 / 29.73 (n=185) |
| react_r | 80.07 (n=271) | 55.68 / 31.18 (n=170) | 41.91 / 11.76 (n=68) | 57.23 / 27.57 (n=185) |
| graphrag | 24.35 (n=271) | 32.63 / 15.88 (n=170) | 49.26 / 5.88 (n=68) | 33.38 / 8.11 (n=185) |
| recode | 15.13 (n=271) | 32.31 / 8.24 (n=170) | 25.74 / 5.88 (n=68) | 27.42 / 3.24 (n=185) |
| react_c | 98.89 (n=271) | 91.23 / 79.41 (n=170) | 100.00 / 100.00 (n=68) | 70.49 / 44.86 (n=185) |
| react_r | 98.89 (n=271) | 93.67 / 85.29 (n=170) | 98.53 / 98.53 (n=68) | 69.15 / 40.00 (n=185) |

### Question accuracy (%) with 95% bootstrap CI

| System | Model | overall | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|---|---|
| react_c | qwen3.6-27b | 81.0 [78.0, 83.7] | 97.0 [95.2, 98.9] | 91.8 [87.7, 95.9] | 95.6 [89.7, 100.0] | 42.2 [34.6, 49.2] |
| react_r | or-qwen3.6-27b | 79.2 [76.1, 82.1] | 97.4 [95.2, 99.3] | 82.3 [76.5, 88.2] | 100.0 [100.0, 100.0] | 42.2 [35.1, 49.7] |
| graphrag | or-qwen3.6-27b | 46.5 [42.8, 50.1] | 72.3 [67.2, 77.5] | 41.8 [34.7, 49.4] | 26.5 [16.2, 36.8] | 20.5 [15.1, 26.5] |
| recode | or-qwen3.6-27b | 59.9 [56.3, 63.4] | 74.9 [69.4, 80.1] | 52.9 [45.3, 60.6] | 94.1 [88.2, 98.5] | 31.9 [25.4, 38.9] |
| react_c | or-gpt-oss-20b | 52.5 [49.0, 56.3] | 85.6 [81.2, 89.7] | 35.9 [28.8, 42.9] | 23.5 [13.2, 33.8] | 29.7 [23.2, 36.2] |
| react_r | or-gpt-oss-20b | 47.4 [43.5, 51.1] | 80.1 [75.3, 84.5] | 31.2 [24.7, 38.2] | 11.8 [4.4, 20.6] | 27.6 [21.1, 34.1] |
| graphrag | or-gpt-oss-20b | 16.1 [13.4, 19.0] | 24.4 [19.2, 29.5] | 15.9 [10.6, 21.8] | 5.9 [1.5, 11.8] | 8.1 [4.3, 12.4] |
| recode | or-gpt-oss-20b | 9.4 [7.2, 11.4] | 15.1 [11.1, 19.6] | 8.2 [4.7, 12.3] | 5.9 [1.5, 11.8] | 3.2 [1.1, 6.0] |
| react_c | or-gemma-4-31b-think | 79.8 [76.8, 82.8] | 98.9 [97.4, 100.0] | 79.4 [72.9, 85.3] | 100.0 [100.0, 100.0] | 44.9 [37.8, 51.9] |
| react_r | or-gemma-4-31b-think | 79.8 [76.8, 82.7] | 98.9 [97.4, 100.0] | 85.3 [79.4, 90.6] | 98.5 [95.6, 100.0] | 40.0 [33.0, 47.6] |

### Descriptive subtypes (accuracy %)

| System | count | exist | query_color | query_material | query_shape |
|---|---|---|---|---|---|
| react_c | 97.12 | 96.08 | 97.78 | 100.00 | 95.24 |
| react_r | 95.19 | 96.08 | 100.00 | 100.00 | 100.00 |
| graphrag | 63.46 | 78.43 | 71.11 | 86.21 | 78.57 |
| recode | 68.27 | 76.47 | 80.00 | 75.86 | 83.33 |
| react_c | 82.69 | 82.35 | 93.33 | 89.66 | 85.71 |
| react_r | 79.81 | 78.43 | 68.89 | 89.66 | 88.10 |
| graphrag | 26.92 | 33.33 | 15.56 | 31.03 | 11.90 |
| recode | 13.46 | 27.45 | 8.89 | 13.79 | 11.90 |
| react_c | 100.00 | 96.08 | 97.78 | 100.00 | 100.00 |
| react_r | 99.04 | 96.08 | 100.00 | 100.00 | 100.00 |

## Token consumption

Query tokens are per question (mean). Cached input is a subset of input; reasoning is a subset of output. Setup = one-time cost (e.g. PageIndex tree build). Amortized = (setup + all query tokens) / questions answered.

| System | Input | Cached input | Output | Reasoning | Total / q | Setup total | Amortized total / q | Sum (all q) | LLM calls / q | Tool calls / q | Latency / q (s) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| react_c | 14,286.1 | 7,479.6 | 6,486.0 | 6,000.1 | 20,772.1 | 0 | 20,772.1 | 14,415,815 | 5.12 | 0.00 | 285.80 |
| react_r | 11,483.6 | 0.0 | 5,143.6 | 4,962.7 | 16,627.2 | 0 | 16,627.2 | 11,539,309 | 4.98 | 0.00 | 81.99 |
| graphrag | 12,229.5 | 0.0 | 2,319.6 | 2,300.2 | 14,549.0 | 22,665,962 | 47,208.9 | 10,097,037 | 1.00 | 0.00 | 42.50 |
| recode | 24,095.9 | 0.0 | 10,945.5 | 10,169.2 | 35,041.4 | 0 | 35,041.4 | 24,318,751 | 5.05 | 0.00 | 191.88 |
| react_c | 9,793.8 | 6,245.3 | 1,020.9 | 955.5 | 10,814.7 | 0 | 10,814.7 | 7,505,376 | 5.96 | 0.00 | 13.07 |
| react_r | 10,056.3 | 6,247.1 | 1,030.7 | 950.6 | 11,087.0 | 0 | 11,087.0 | 7,694,372 | 6.85 | 0.00 | 17.31 |
| graphrag | 10,545.7 | 1,121.7 | 873.5 | 928.0 | 11,419.2 | 15,368,448 | 33,563.9 | 7,924,929 | 1.00 | 0.00 | 9.67 |
| recode | 7,547.2 | 6,263.4 | 4,001.3 | 3,904.6 | 11,548.4 | 0 | 11,548.4 | 8,014,605 | 2.00 | 0.00 | 35.70 |
| react_c | 13,460.2 | 8,054.8 | 3,663.7 | 2,696.6 | 17,123.9 | 0 | 17,123.9 | 11,883,974 | 5.72 | 0.00 | 122.86 |
| react_r | 12,800.4 | 7,285.8 | 3,384.2 | 2,521.0 | 16,184.5 | 0 | 16,184.5 | 11,232,075 | 6.00 | 0.00 | 212.59 |

### Mean total tokens per question, by type

| System | descriptive | explanatory | predictive | counterfactual |
|---|---|---|---|---|
| react_c | 12,044.9 | 20,394.1 | 29,665.7 | 30,634.5 |
| react_r | 10,787.6 | 17,552.0 | 18,221.2 | 23,745.9 |
| graphrag | 13,710.1 | 14,714.6 | 14,859.0 | 15,512.0 |
| recode | 34,830.8 | 34,017.7 | 34,088.2 | 36,641.0 |
| react_c | 10,670.5 | 9,053.3 | 10,814.5 | 12,644.5 |
| react_r | 10,715.6 | 9,478.8 | 12,995.8 | 12,407.2 |
| graphrag | 11,331.0 | 11,360.9 | 11,470.2 | 11,583.2 |
| recode | 12,464.0 | 10,534.9 | 11,203.6 | 11,265.2 |
| react_c | 11,309.6 | 16,221.4 | 20,875.2 | 25,091.5 |
| react_r | 11,456.8 | 14,760.2 | 18,959.6 | 23,398.9 |

### Setup details

- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 40.5s, info: `{"documents": 5}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.1s, info: `{"documents": 5}`
- **graphrag**: 22,665,962 tokens (9,031,947 in / 13,634,015 out, 5201 calls), 20732.1s, info: `{"documents": 5}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.1s, info: `{"documents": 5}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.1s, info: `{"documents": 5}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.1s, info: `{"documents": 5}`
- **graphrag**: 15,368,448 tokens (9,100,002 in / 6,268,446 out, 5744 calls), 7107.3s, info: `{"documents": 5}`
- **recode**: 0 tokens (0 in / 0 out, 0 calls), 0.1s, info: `{"documents": 5}`
- **react_c**: 0 tokens (0 in / 0 out, 0 calls), 0.1s, info: `{"documents": 5}`
- **react_r**: 0 tokens (0 in / 0 out, 0 calls), 0.2s, info: `{"documents": 5}`
